export interface Poem {
  id: string;
  title: string;
  author: string;
  body: string;
  category: string;
  date: string;
}
