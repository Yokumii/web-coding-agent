export interface Comment {
  id: string;
  poemId: string;
  name: string;
  text: string;
  date: string;
}
