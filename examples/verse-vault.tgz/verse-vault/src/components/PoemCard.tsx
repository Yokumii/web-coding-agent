import { Link } from 'react-router-dom';
import type { Poem } from '../types/poem';
import CategoryBadge from './CategoryBadge';

interface PoemCardProps {
  poem: Poem;
}

export default function PoemCard({ poem }: PoemCardProps) {
  const preview = poem.body.split('\n').slice(0, 3).join(' ').substring(0, 120) + '...';

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <Link
      to={`/poem/${poem.id}`}
      style={{
        display: 'block',
        backgroundColor: '#FFFACD',
        border: '1px solid #DAA520',
        borderRadius: 12,
        padding: 24,
        textDecoration: 'none',
        color: '#2F2F2F',
        transition: 'all 250ms cubic-bezier(0.4, 0, 0.2, 1)',
        boxShadow: '0 2px 8px rgba(184, 134, 11, 0.1)',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = '#F0E68C';
        e.currentTarget.style.transform = 'translateY(-2px)';
        e.currentTarget.style.boxShadow = '0 4px 16px rgba(184, 134, 11, 0.2)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = '#FFFACD';
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = '0 2px 8px rgba(184, 134, 11, 0.1)';
      }}
    >
      <h2
        style={{
          fontSize: '1.25rem',
          fontWeight: 700,
          marginBottom: 8,
          fontFamily: "'Playfair Display', Georgia, serif",
          color: '#2F2F2F',
        }}
      >
        {poem.title}
      </h2>
      <p
        style={{
          fontSize: '0.875rem',
          color: '#5D5D5D',
          marginBottom: 12,
          fontFamily: "'Inter', system-ui, sans-serif",
        }}
      >
        by {poem.author}
      </p>
      <p
        style={{
          fontSize: '1rem',
          lineHeight: 1.6,
          color: '#5D5D5D',
          marginBottom: 16,
          fontStyle: 'italic',
        }}
      >
        {preview}
      </p>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '0.75rem',
          fontFamily: "'Inter', system-ui, sans-serif",
          color: '#5D5D5D',
        }}
      >
        <CategoryBadge category={poem.category} />
        <span>{formatDate(poem.date)}</span>
      </div>
    </Link>
  );
}
