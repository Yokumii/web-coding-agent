import { useState } from 'react';
import type { Poem } from '../types/poem';

interface CategoryFilterProps {
  poems: Poem[];
  selectedCategories: string[];
  onToggleCategory: (category: string) => void;
}

const PREDEFINED_CATEGORIES = ['Sonnet', 'Haiku', 'Free Verse', 'Limerick', 'Ballad', 'Other'];

export default function CategoryFilter({ poems, selectedCategories, onToggleCategory }: CategoryFilterProps) {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  const getCategoryCount = (category: string) => {
    return poems.filter((p) => p.category === category).length;
  };

  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: 8,
        alignItems: 'center',
      }}
    >
      {PREDEFINED_CATEGORIES.map((category) => {
        const isSelected = selectedCategories.includes(category);
        const isHovered = hoveredCategory === category;
        const count = getCategoryCount(category);

        return (
          <button
            key={category}
            type="button"
            aria-pressed={isSelected}
            onClick={() => onToggleCategory(category)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 16px',
              borderRadius: 9999,
              border: '1px solid',
              borderColor: isSelected ? '#556B2F' : isHovered ? '#B8860B' : '#DAA520',
              backgroundColor: isSelected ? '#6B8E23' : isHovered ? '#F0E68C' : '#FFFFFF',
              color: isSelected ? '#FFFFFF' : '#2F2F2F',
              fontSize: '0.875rem',
              fontFamily: "'Inter', system-ui, sans-serif",
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
              opacity: count === 0 ? 0.5 : 1,
              pointerEvents: count === 0 ? 'none' : 'auto',
              boxShadow: isSelected ? '0 0 0 2px rgba(85, 107, 47, 0.18)' : 'none',
            }}
            onMouseEnter={() => setHoveredCategory(category)}
            onMouseLeave={() =>
              setHoveredCategory((current) => (current === category ? null : current))
            }
            onFocus={() => setHoveredCategory(category)}
            onBlur={() =>
              setHoveredCategory((current) => (current === category ? null : current))
            }
          >
            <span>{category}</span>
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                minWidth: 20,
                height: 20,
                padding: '0 6px',
                borderRadius: 9999,
                backgroundColor: isSelected ? 'rgba(255,255,255,0.25)' : '#F0E68C',
                color: isSelected ? '#FFFFFF' : '#5D5D5D',
                fontSize: '0.75rem',
                fontWeight: 600,
              }}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
}
