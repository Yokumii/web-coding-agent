import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';

export default function Layout() {
  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: '#FAFAD2',
        fontFamily: "'Playfair Display', Georgia, serif",
        color: '#2F2F2F',
      }}
    >
      <Navbar />
      <main style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px 24px' }}>
        <Outlet />
      </main>
    </div>
  );
}
