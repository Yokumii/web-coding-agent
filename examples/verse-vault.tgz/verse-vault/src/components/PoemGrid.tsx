import type { Poem } from '../types/poem';
import PoemCard from './PoemCard';

interface PoemGridProps {
  poems: Poem[];
}

export default function PoemGrid({ poems }: PoemGridProps) {
  if (poems.length === 0) {
    return (
      <div
        style={{
          textAlign: 'center',
          padding: '64px 24px',
          color: '#5D5D5D',
        }}
      >
        <p style={{ fontSize: '1.25rem', marginBottom: 8 }}>
          No poems found
        </p>
        <p style={{ fontSize: '0.875rem' }}>
          The vault is empty. Check back later for new verses.
        </p>
      </div>
    );
  }

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
        gap: 24,
      }}
    >
      {poems.map((poem) => (
        <PoemCard key={poem.id} poem={poem} />
      ))}
    </div>
  );
}
