import { useState } from 'react';
import type { Poem } from '../types/poem';

interface CategorySidebarProps {
  poems: Poem[];
  selectedCategories: string[];
  onToggleCategory: (category: string) => void;
}

const PREDEFINED_CATEGORIES = ['Sonnet', 'Haiku', 'Free Verse', 'Limerick', 'Ballad', 'Other'];

export default function CategorySidebar({ poems, selectedCategories, onToggleCategory }: CategorySidebarProps) {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  const getCategoryCount = (category: string) => {
    return poems.filter((p) => p.category === category).length;
  };

  const totalPoems = poems.length;

  return (
    <div
      style={{
        backgroundColor: '#FFFACD',
        border: '1px solid #DAA520',
        borderRadius: 12,
        padding: 24,
        position: 'sticky',
        top: 80,
      }}
    >
      <h3
        style={{
          fontSize: '1rem',
          fontWeight: 700,
          marginBottom: 16,
          fontFamily: "'Playfair Display', Georgia, serif",
          color: '#2F2F2F',
        }}
      >
        Categories
      </h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {PREDEFINED_CATEGORIES.map((category) => {
          const isSelected = selectedCategories.includes(category);
          const isHovered = hoveredCategory === category;
          const count = getCategoryCount(category);

          return (
            <button
              key={category}
              type="button"
              aria-pressed={isSelected}
              onClick={() => onToggleCategory(category)}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '10px 12px',
                borderRadius: 8,
                border: 'none',
                backgroundColor: isSelected ? '#6B8E23' : isHovered ? '#F0E68C' : 'transparent',
                color: isSelected ? '#FFFFFF' : '#2F2F2F',
                fontSize: '0.875rem',
                fontFamily: "'Inter', system-ui, sans-serif",
                fontWeight: isSelected ? 600 : 400,
                cursor: 'pointer',
                transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
                textAlign: 'left',
                opacity: count === 0 ? 0.5 : 1,
                pointerEvents: count === 0 ? 'none' : 'auto',
                boxShadow: isSelected ? 'inset 0 0 0 1px rgba(255,255,255,0.22)' : 'none',
              }}
              onMouseEnter={() => setHoveredCategory(category)}
              onMouseLeave={() =>
                setHoveredCategory((current) => (current === category ? null : current))
              }
              onFocus={() => setHoveredCategory(category)}
              onBlur={() =>
                setHoveredCategory((current) => (current === category ? null : current))
              }
            >
              <span>{category}</span>
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  minWidth: 24,
                  height: 24,
                  padding: '0 8px',
                  borderRadius: 9999,
                  backgroundColor: isSelected ? 'rgba(255,255,255,0.25)' : '#F0E68C',
                  color: isSelected ? '#FFFFFF' : '#5D5D5D',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                }}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
      <div
        style={{
          marginTop: 16,
          paddingTop: 16,
          borderTop: '1px solid #DAA520',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '0.875rem',
          fontFamily: "'Inter', system-ui, sans-serif",
          color: '#5D5D5D',
        }}
      >
        <span>Total</span>
        <span style={{ fontWeight: 600, color: '#2F2F2F' }}>{totalPoems}</span>
      </div>
    </div>
  );
}
