import { useState, useCallback } from 'react';
import { getCommentsForPoem, addComment } from '../utils/comments';
import type { Comment } from '../types/comment';

interface CommentSectionProps {
  poemId: string;
}

interface FormErrors {
  name?: string;
  text?: string;
}

export default function CommentSection({ poemId }: CommentSectionProps) {
  const [comments, setComments] = useState<Comment[]>(() => getCommentsForPoem(poemId));
  const [name, setName] = useState('');
  const [text, setText] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const validate = useCallback((n: string, t: string): FormErrors => {
    const newErrors: FormErrors = {};
    if (!n.trim()) {
      newErrors.name = 'Name is required';
    }
    if (!t.trim()) {
      newErrors.text = 'Comment is required';
    }
    return newErrors;
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate(name, text);
    setErrors(validationErrors);
    setTouched({ name: true, text: true });

    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    const newComment: Comment = {
      id: crypto.randomUUID(),
      poemId,
      name: name.trim(),
      text: text.trim(),
      date: new Date().toISOString(),
    };

    addComment(newComment);
    setComments((prev) => [...prev, newComment]);
    setName('');
    setText('');
    setTouched({});
    setErrors({});
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const inputStyle = (field: 'name' | 'text'): React.CSSProperties => ({
    width: '100%',
    padding: '12px 16px',
    borderRadius: 8,
    border: `1px solid ${touched[field] && errors[field] ? '#8B0000' : '#DAA520'}`,
    backgroundColor: '#FFFFFF',
    fontSize: '1rem',
    fontFamily: "'Inter', system-ui, sans-serif",
    color: '#2F2F2F',
    outline: 'none',
    transition: 'border-color 150ms cubic-bezier(0.4, 0, 0.2, 1)',
  });

  const labelStyle: React.CSSProperties = {
    display: 'block',
    fontSize: '0.875rem',
    fontWeight: 500,
    fontFamily: "'Inter', system-ui, sans-serif",
    color: '#2F2F2F',
    marginBottom: 6,
  };

  return (
    <section
      style={{
        marginTop: 48,
        paddingTop: 48,
        borderTop: '1px solid #DAA520',
      }}
    >
      <h2
        style={{
          fontSize: '1.75rem',
          fontWeight: 700,
          marginBottom: 32,
          fontFamily: "'Playfair Display', Georgia, serif",
          color: '#2F2F2F',
          letterSpacing: '-0.01em',
        }}
      >
        Comments
      </h2>

      <form onSubmit={handleSubmit} noValidate style={{ marginBottom: 48 }}>
        <div style={{ marginBottom: 20 }}>
          <label htmlFor="comment-name" style={labelStyle}>
            Name <span style={{ color: '#8B0000' }}>*</span>
          </label>
          <input
            id="comment-name"
            type="text"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setErrors(validate(e.target.value, text));
            }}
            onBlur={() => setTouched((prev) => ({ ...prev, name: true }))}
            style={inputStyle('name')}
            placeholder="Your name"
          />
          {touched.name && errors.name && (
            <p
              style={{
                color: '#8B0000',
                fontSize: '0.875rem',
                marginTop: 6,
                fontFamily: "'Inter', system-ui, sans-serif",
              }}
            >
              {errors.name}
            </p>
          )}
        </div>

        <div style={{ marginBottom: 24 }}>
          <label htmlFor="comment-text" style={labelStyle}>
            Comment <span style={{ color: '#8B0000' }}>*</span>
          </label>
          <textarea
            id="comment-text"
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              setErrors(validate(name, e.target.value));
            }}
            onBlur={() => setTouched((prev) => ({ ...prev, text: true }))}
            style={{
              ...inputStyle('text'),
              minHeight: 120,
              resize: 'vertical',
              fontFamily: "'Inter', system-ui, sans-serif",
              lineHeight: 1.6,
            }}
            placeholder="Share your thoughts..."
          />
          {touched.text && errors.text && (
            <p
              style={{
                color: '#8B0000',
                fontSize: '0.875rem',
                marginTop: 6,
                fontFamily: "'Inter', system-ui, sans-serif",
              }}
            >
              {errors.text}
            </p>
          )}
        </div>

        <button
          type="submit"
          style={{
            padding: '12px 28px',
            borderRadius: 8,
            border: 'none',
            backgroundColor: '#6B8E23',
            color: '#FFFFFF',
            fontSize: '0.9375rem',
            fontFamily: "'Inter', system-ui, sans-serif",
            fontWeight: 500,
            cursor: 'pointer',
            transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#556B2F';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#6B8E23';
          }}
        >
          Post Comment
        </button>
      </form>

      {comments.length === 0 ? (
        <div
          style={{
            textAlign: 'center',
            padding: '40px 24px',
            color: '#5D5D5D',
            fontFamily: "'Inter', system-ui, sans-serif",
            fontSize: '0.9375rem',
          }}
        >
          <svg
            width="48"
            height="48"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#B8860B"
            strokeWidth="1.5"
            style={{ marginBottom: 16 }}
          >
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <p style={{ fontWeight: 500, marginBottom: 4 }}>No comments yet</p>
          <p style={{ fontSize: '0.875rem', color: '#5D5D5D' }}>
            Be the first to share your thoughts on this poem.
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {comments.map((comment) => (
            <div
              key={comment.id}
              style={{
                backgroundColor: '#FFFACD',
                border: '1px solid #DAA520',
                borderRadius: 12,
                padding: '20px 24px',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 12,
                }}
              >
                <span
                  style={{
                    fontWeight: 700,
                    fontSize: '0.9375rem',
                    fontFamily: "'Inter', system-ui, sans-serif",
                    color: '#2F2F2F',
                  }}
                >
                  {comment.name}
                </span>
                <span
                  style={{
                    fontSize: '0.75rem',
                    fontFamily: "'Inter', system-ui, sans-serif",
                    color: '#5D5D5D',
                  }}
                >
                  {formatDate(comment.date)}
                </span>
              </div>
              <p
                style={{
                  fontSize: '0.9375rem',
                  lineHeight: 1.6,
                  fontFamily: "'Inter', system-ui, sans-serif",
                  color: '#2F2F2F',
                  whiteSpace: 'pre-wrap',
                  margin: 0,
                }}
              >
                {comment.text}
              </p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
