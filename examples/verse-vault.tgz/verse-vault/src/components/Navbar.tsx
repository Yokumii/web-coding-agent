import { Link, useLocation } from 'react-router-dom';

export default function Navbar() {
  const location = useLocation();
  const isPostPage = location.pathname === '/post';

  return (
    <nav
      style={{
        position: 'sticky',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        backgroundColor: '#6B8E23',
        padding: '16px 24px',
        boxShadow: '0 2px 8px rgba(184, 134, 11, 0.15)',
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Link
          to="/"
          style={{
            color: '#FFFFFF',
            textDecoration: 'none',
            fontSize: '1.5rem',
            fontWeight: 700,
            fontFamily: "'Playfair Display', Georgia, serif",
            letterSpacing: '0.05em',
          }}
        >
          VerseVault
        </Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <Link
            to="/post"
            style={{
              color: isPostPage ? '#FFFFFF' : 'rgba(255, 255, 255, 0.85)',
              textDecoration: 'none',
              fontSize: '0.875rem',
              fontFamily: "'Inter', system-ui, sans-serif",
              fontWeight: isPostPage ? 700 : 500,
              padding: '6px 14px',
              borderRadius: 6,
              backgroundColor: isPostPage ? 'rgba(255,255,255,0.15)' : 'transparent',
              transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
            }}
            onMouseEnter={(e) => {
              if (!isPostPage) {
                e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)';
              }
            }}
            onMouseLeave={(e) => {
              if (!isPostPage) {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
          >
            Post
          </Link>
          <span
            style={{
              color: 'rgba(255, 255, 255, 0.85)',
              fontSize: '0.875rem',
              fontFamily: "'Inter', system-ui, sans-serif",
            }}
          >
            A Sanctuary for Poetry
          </span>
        </div>
      </div>
    </nav>
  );
}
