interface CategoryBadgeProps {
  category: string;
  size?: 'sm' | 'md';
}

export default function CategoryBadge({ category, size = 'sm' }: CategoryBadgeProps) {
  const padding = size === 'md' ? '4px 16px' : '4px 12px';
  const fontSize = size === 'md' ? '0.75rem' : '0.75rem';

  return (
    <span
      style={{
        display: 'inline-block',
        backgroundColor: '#6B8E23',
        color: '#FFFFFF',
        padding,
        borderRadius: 9999,
        fontSize,
        fontWeight: 500,
        fontFamily: "'Inter', system-ui, sans-serif",
        lineHeight: 1,
      }}
    >
      {category}
    </span>
  );
}
