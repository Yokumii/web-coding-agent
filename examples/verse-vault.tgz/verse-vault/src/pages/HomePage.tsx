import { useEffect, useState, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import type { Poem } from '../types/poem';
import { getPoems } from '../utils/storage';
import PoemGrid from '../components/PoemGrid';
import SearchBar from '../components/SearchBar';
import CategoryFilter from '../components/CategoryFilter';
import CategorySidebar from '../components/CategorySidebar';

export default function HomePage() {
  const [poems, setPoems] = useState<Poem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  const loadPoems = useCallback(() => {
    const stored = getPoems();
    setPoems(stored);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadPoems();
  }, [loadPoems]);

  useEffect(() => {
    const handleFocus = () => {
      loadPoems();
    };
    window.addEventListener('focus', handleFocus);
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [loadPoems]);

  const filteredPoems = useMemo(() => {
    let result = [...poems];

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      result = result.filter(
        (poem) =>
          poem.title.toLowerCase().includes(query) ||
          poem.author.toLowerCase().includes(query) ||
          poem.body.toLowerCase().includes(query)
      );
    }

    if (selectedCategories.length > 0) {
      result = result.filter((poem) => selectedCategories.includes(poem.category));
    }

    return result;
  }, [poems, searchQuery, selectedCategories]);

  const handleToggleCategory = useCallback((category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category]
    );
  }, []);

  const handleClear = () => {
    setSearchQuery('');
    setSelectedCategories([]);
  };

  const hasActiveFilters = searchQuery.trim().length > 0 || selectedCategories.length > 0;

  return (
    <div>
      <div style={{ marginBottom: 32, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1
            style={{
              fontSize: '2.5rem',
              fontWeight: 700,
              marginBottom: 8,
              fontFamily: "'Playfair Display', Georgia, serif",
              color: '#2F2F2F',
              letterSpacing: '-0.01em',
            }}
          >
            Poetry Feed
          </h1>
          <p
            style={{
              fontSize: '1.125rem',
              color: '#5D5D5D',
              fontFamily: "'Inter', system-ui, sans-serif",
            }}
          >
            Discover timeless verses from classic poets
          </p>
        </div>
        <Link
          to="/post"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            padding: '12px 24px',
            borderRadius: 8,
            backgroundColor: '#6B8E23',
            color: '#FFFFFF',
            textDecoration: 'none',
            fontSize: '0.875rem',
            fontFamily: "'Inter', system-ui, sans-serif",
            fontWeight: 500,
            transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
            flexShrink: 0,
            marginTop: 8,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#556B2F';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#6B8E23';
          }}
        >
          <span style={{ fontSize: '1rem' }}>+</span> Post a Poem
        </Link>
      </div>

      <div style={{ display: 'flex', gap: 32, alignItems: 'flex-start' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ marginBottom: 24 }}>
            <SearchBar value={searchQuery} onChange={setSearchQuery} />
          </div>

          <div style={{ marginBottom: 24 }}>
            <CategoryFilter
              poems={poems}
              selectedCategories={selectedCategories}
              onToggleCategory={handleToggleCategory}
            />
          </div>

          {hasActiveFilters && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 24,
                padding: '12px 16px',
                backgroundColor: '#FFFACD',
                border: '1px solid #DAA520',
                borderRadius: 8,
              }}
            >
              <span
                style={{
                  fontSize: '0.875rem',
                  fontFamily: "'Inter', system-ui, sans-serif",
                  color: '#5D5D5D',
                }}
              >
                Showing {filteredPoems.length} result{filteredPoems.length !== 1 ? 's' : ''}
                {searchQuery && (
                  <span>
                    {' '}
                    for &ldquo;{searchQuery}&rdquo;
                  </span>
                )}
              </span>
              <button
                onClick={handleClear}
                style={{
                  padding: '6px 14px',
                  borderRadius: 6,
                  border: '1px solid #DAA520',
                  backgroundColor: '#FFFFFF',
                  color: '#6B8E23',
                  fontSize: '0.875rem',
                  fontFamily: "'Inter', system-ui, sans-serif",
                  fontWeight: 500,
                  cursor: 'pointer',
                  transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#F0E68C';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#FFFFFF';
                }}
              >
                Clear all
              </button>
            </div>
          )}

          {loading ? (
            <div
              style={{
                textAlign: 'center',
                padding: '64px 24px',
                color: '#5D5D5D',
                fontFamily: "'Inter', system-ui, sans-serif",
              }}
            >
              Loading poems...
            </div>
          ) : (
            <PoemGrid poems={filteredPoems} />
          )}
        </div>

        <div style={{ width: 240, flexShrink: 0 }}>
          <CategorySidebar
            poems={poems}
            selectedCategories={selectedCategories}
            onToggleCategory={handleToggleCategory}
          />
        </div>
      </div>
    </div>
  );
}
