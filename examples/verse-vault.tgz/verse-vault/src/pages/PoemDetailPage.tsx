import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import type { Poem } from '../types/poem';
import { getPoemById } from '../utils/storage';
import CategoryBadge from '../components/CategoryBadge';
import CommentSection from '../components/CommentSection';

export default function PoemDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [poem, setPoem] = useState<Poem | null>(null);

  useEffect(() => {
    if (id) {
      const found = getPoemById(id);
      if (found) {
        setPoem(found);
      }
    }
  }, [id]);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (!poem) {
    return (
      <div
        style={{
          textAlign: 'center',
          padding: '64px 24px',
          color: '#5D5D5D',
          fontFamily: "'Inter', system-ui, sans-serif",
        }}
      >
        <p style={{ fontSize: '1.25rem', marginBottom: 16 }}>Poem not found</p>
        <Link
          to="/"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            color: '#6B8E23',
            textDecoration: 'none',
            fontWeight: 500,
            fontSize: '0.875rem',
          }}
        >
          <span>&larr;</span> Back to feed
        </Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      <Link
        to="/"
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 8,
          color: '#6B8E23',
          textDecoration: 'none',
          fontSize: '0.875rem',
          fontWeight: 500,
          fontFamily: "'Inter', system-ui, sans-serif",
          marginBottom: 32,
          transition: 'color 150ms cubic-bezier(0.4, 0, 0.2, 1)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.color = '#556B2F';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.color = '#6B8E23';
        }}
      >
        <span>&larr;</span> Back to feed
      </Link>

      <article
        style={{
          backgroundColor: '#FFFACD',
          border: '1px solid #DAA520',
          borderRadius: 12,
          padding: '48px 40px',
        }}
      >
        <header style={{ marginBottom: 40, textAlign: 'center' }}>
          <h1
            style={{
              fontSize: '2.5rem',
              fontWeight: 700,
              marginBottom: 16,
              fontFamily: "'Playfair Display', Georgia, serif",
              color: '#2F2F2F',
              lineHeight: 1.3,
              letterSpacing: '-0.01em',
            }}
          >
            {poem.title}
          </h1>
          <p
            style={{
              fontSize: '1.125rem',
              color: '#5D5D5D',
              marginBottom: 20,
              fontFamily: "'Playfair Display', Georgia, serif",
              fontStyle: 'italic',
            }}
          >
            by {poem.author}
          </p>
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              gap: 16,
              alignItems: 'center',
              fontSize: '0.875rem',
              fontFamily: "'Inter', system-ui, sans-serif",
              color: '#5D5D5D',
            }}
          >
            <CategoryBadge category={poem.category} size="md" />
            <span>{formatDate(poem.date)}</span>
          </div>
        </header>

        <div
          style={{
            fontSize: '1.125rem',
            lineHeight: 1.8,
            fontFamily: "'Playfair Display', Georgia, serif",
            color: '#2F2F2F',
            whiteSpace: 'pre-wrap',
            padding: '0 8px',
          }}
        >
          {poem.body}
        </div>
      </article>

      <CommentSection poemId={poem.id} />
    </div>
  );
}
