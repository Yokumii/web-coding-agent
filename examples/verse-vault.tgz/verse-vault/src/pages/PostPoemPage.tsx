import { useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { addPoem } from '../utils/storage';
import CategoryBadge from '../components/CategoryBadge';

const PREDEFINED_CATEGORIES = ['Sonnet', 'Haiku', 'Free Verse', 'Limerick', 'Ballad', 'Other'];

interface FormData {
  title: string;
  author: string;
  body: string;
  category: string;
}

interface FormErrors {
  title?: string;
  author?: string;
  body?: string;
  category?: string;
}

export default function PostPoemPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormData>({
    title: '',
    author: '',
    body: '',
    category: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [success, setSuccess] = useState(false);

  const validate = useCallback((data: FormData): FormErrors => {
    const newErrors: FormErrors = {};
    if (!data.title.trim()) {
      newErrors.title = 'Title is required';
    }
    if (!data.author.trim()) {
      newErrors.author = 'Author is required';
    }
    if (!data.body.trim()) {
      newErrors.body = 'Poem body is required';
    }
    if (!data.category) {
      newErrors.category = 'Category is required';
    }
    return newErrors;
  }, []);

  const handleChange = (field: keyof FormData, value: string) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    setErrors(validate(updated));
    setSuccess(false);
  };

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate(formData);
    setErrors(validationErrors);
    setTouched({ title: true, author: true, body: true, category: true });

    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    const newPoem = {
      id: crypto.randomUUID(),
      title: formData.title.trim(),
      author: formData.author.trim(),
      body: formData.body.trim(),
      category: formData.category,
      date: new Date().toISOString().split('T')[0],
    };

    addPoem(newPoem);

    setFormData({ title: '', author: '', body: '', category: '' });
    setTouched({});
    setErrors({});
    setSuccess(true);

    setTimeout(() => {
      navigate('/');
    }, 1500);
  };

  const previewPoem = {
    title: formData.title || 'Your Poem Title',
    author: formData.author || 'Author Name',
    body: formData.body || 'Your poem will appear here...',
    category: formData.category || 'Free Verse',
    date: new Date().toISOString().split('T')[0],
  };

  const inputStyle = (field: keyof FormData): React.CSSProperties => ({
    width: '100%',
    padding: '12px 16px',
    borderRadius: 8,
    border: `1px solid ${touched[field] && errors[field] ? '#8B0000' : '#DAA520'}`,
    backgroundColor: '#FFFFFF',
    fontSize: '1rem',
    fontFamily: "'Inter', system-ui, sans-serif",
    color: '#2F2F2F',
    outline: 'none',
    transition: 'border-color 150ms cubic-bezier(0.4, 0, 0.2, 1)',
  });

  const labelStyle: React.CSSProperties = {
    display: 'block',
    fontSize: '0.875rem',
    fontWeight: 500,
    fontFamily: "'Inter', system-ui, sans-serif",
    color: '#2F2F2F',
    marginBottom: 6,
  };

  return (
    <div>
      <Link
        to="/"
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 8,
          color: '#6B8E23',
          textDecoration: 'none',
          fontSize: '0.875rem',
          fontWeight: 500,
          fontFamily: "'Inter', system-ui, sans-serif",
          marginBottom: 32,
          transition: 'color 150ms cubic-bezier(0.4, 0, 0.2, 1)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.color = '#556B2F';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.color = '#6B8E23';
        }}
      >
        <span>&larr;</span> Back to feed
      </Link>

      <div style={{ display: 'flex', gap: 32, alignItems: 'flex-start' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1
            style={{
              fontSize: '2rem',
              fontWeight: 700,
              marginBottom: 8,
              fontFamily: "'Playfair Display', Georgia, serif",
              color: '#2F2F2F',
              letterSpacing: '-0.01em',
            }}
          >
            Post a Poem
          </h1>
          <p
            style={{
              fontSize: '1.125rem',
              color: '#5D5D5D',
              marginBottom: 32,
              fontFamily: "'Inter', system-ui, sans-serif",
            }}
          >
            Share your verse with the world
          </p>

          {success && (
            <div
              style={{
                padding: '16px 20px',
                borderRadius: 8,
                backgroundColor: '#E8F5E9',
                border: '1px solid #228B22',
                marginBottom: 24,
                display: 'flex',
                alignItems: 'center',
                gap: 10,
              }}
            >
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#228B22"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="20 6 9 17 4 12" />
              </svg>
              <span
                style={{
                  color: '#228B22',
                  fontSize: '0.875rem',
                  fontWeight: 500,
                  fontFamily: "'Inter', system-ui, sans-serif",
                }}
              >
                Poem posted successfully! Redirecting to feed...
              </span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div style={{ marginBottom: 24 }}>
              <label htmlFor="title" style={labelStyle}>
                Title <span style={{ color: '#8B0000' }}>*</span>
              </label>
              <input
                id="title"
                type="text"
                value={formData.title}
                onChange={(e) => handleChange('title', e.target.value)}
                onBlur={() => handleBlur('title')}
                style={inputStyle('title')}
                placeholder="Enter poem title"
              />
              {touched.title && errors.title && (
                <p
                  style={{
                    color: '#8B0000',
                    fontSize: '0.875rem',
                    marginTop: 6,
                    fontFamily: "'Inter', system-ui, sans-serif",
                  }}
                >
                  {errors.title}
                </p>
              )}
            </div>

            <div style={{ marginBottom: 24 }}>
              <label htmlFor="author" style={labelStyle}>
                Author <span style={{ color: '#8B0000' }}>*</span>
              </label>
              <input
                id="author"
                type="text"
                value={formData.author}
                onChange={(e) => handleChange('author', e.target.value)}
                onBlur={() => handleBlur('author')}
                style={inputStyle('author')}
                placeholder="Enter author name"
              />
              {touched.author && errors.author && (
                <p
                  style={{
                    color: '#8B0000',
                    fontSize: '0.875rem',
                    marginTop: 6,
                    fontFamily: "'Inter', system-ui, sans-serif",
                  }}
                >
                  {errors.author}
                </p>
              )}
            </div>

            <div style={{ marginBottom: 24 }}>
              <label htmlFor="category" style={labelStyle}>
                Category <span style={{ color: '#8B0000' }}>*</span>
              </label>
              <select
                id="category"
                value={formData.category}
                onChange={(e) => handleChange('category', e.target.value)}
                onBlur={() => handleBlur('category')}
                style={{
                  ...inputStyle('category'),
                  appearance: 'auto',
                  cursor: 'pointer',
                }}
              >
                <option value="">Select a category</option>
                {PREDEFINED_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              {touched.category && errors.category && (
                <p
                  style={{
                    color: '#8B0000',
                    fontSize: '0.875rem',
                    marginTop: 6,
                    fontFamily: "'Inter', system-ui, sans-serif",
                  }}
                >
                  {errors.category}
                </p>
              )}
            </div>

            <div style={{ marginBottom: 32 }}>
              <label htmlFor="body" style={labelStyle}>
                Poem Body <span style={{ color: '#8B0000' }}>*</span>
              </label>
              <textarea
                id="body"
                value={formData.body}
                onChange={(e) => handleChange('body', e.target.value)}
                onBlur={() => handleBlur('body')}
                style={{
                  ...inputStyle('body'),
                  minHeight: 200,
                  resize: 'vertical',
                  fontFamily: "'Playfair Display', Georgia, serif",
                  lineHeight: 1.8,
                }}
                placeholder="Write your poem here..."
              />
              {touched.body && errors.body && (
                <p
                  style={{
                    color: '#8B0000',
                    fontSize: '0.875rem',
                    marginTop: 6,
                    fontFamily: "'Inter', system-ui, sans-serif",
                  }}
                >
                  {errors.body}
                </p>
              )}
            </div>

            <button
              type="submit"
              style={{
                padding: '14px 32px',
                borderRadius: 8,
                border: 'none',
                backgroundColor: '#6B8E23',
                color: '#FFFFFF',
                fontSize: '1rem',
                fontFamily: "'Inter', system-ui, sans-serif",
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 150ms cubic-bezier(0.4, 0, 0.2, 1)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#556B2F';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#6B8E23';
              }}
            >
              Publish Poem
            </button>
          </form>
        </div>

        <div style={{ width: 360, flexShrink: 0 }}>
          <h2
            style={{
              fontSize: '1.25rem',
              fontWeight: 700,
              marginBottom: 16,
              fontFamily: "'Playfair Display', Georgia, serif",
              color: '#2F2F2F',
            }}
          >
            Preview
          </h2>
          <div
            style={{
              backgroundColor: '#FFFACD',
              border: '1px solid #DAA520',
              borderRadius: 12,
              padding: 24,
              boxShadow: '0 2px 8px rgba(184, 134, 11, 0.1)',
            }}
          >
            <h3
              style={{
                fontSize: '1.25rem',
                fontWeight: 700,
                marginBottom: 8,
                fontFamily: "'Playfair Display', Georgia, serif",
                color: '#2F2F2F',
              }}
            >
              {previewPoem.title}
            </h3>
            <p
              style={{
                fontSize: '0.875rem',
                color: '#5D5D5D',
                marginBottom: 12,
                fontFamily: "'Inter', system-ui, sans-serif",
              }}
            >
              by {previewPoem.author}
            </p>
            <p
              style={{
                fontSize: '1rem',
                lineHeight: 1.8,
                color: '#5D5D5D',
                marginBottom: 16,
                fontStyle: 'italic',
                whiteSpace: 'pre-wrap',
              }}
            >
              {previewPoem.body}
            </p>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                fontSize: '0.75rem',
                fontFamily: "'Inter', system-ui, sans-serif",
                color: '#5D5D5D',
              }}
            >
              <CategoryBadge category={previewPoem.category} />
              <span>
                {new Date(previewPoem.date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
