import type { Comment } from '../types/comment';

const STORAGE_KEY = 'versevault_comments';

export function getComments(): Comment[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    return JSON.parse(raw) as Comment[];
  } catch {
    return [];
  }
}

export function getCommentsForPoem(poemId: string): Comment[] {
  return getComments()
    .filter((c) => c.poemId === poemId)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}

export function saveComments(comments: Comment[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(comments));
}

export function addComment(comment: Comment): void {
  const comments = getComments();
  comments.push(comment);
  saveComments(comments);
}
