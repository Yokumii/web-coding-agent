import type { Poem } from '../types/poem';
import { samplePoems } from '../data/samplePoems';

const STORAGE_KEY = 'versevault_poems';

export function getPoems(): Poem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      savePoems(samplePoems);
      return [...samplePoems];
    }
    return JSON.parse(raw) as Poem[];
  } catch {
    return [];
  }
}

export function savePoems(poems: Poem[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(poems));
}

export function addPoem(poem: Poem): void {
  const poems = getPoems();
  poems.push(poem);
  savePoems(poems);
}

export function getPoemById(id: string): Poem | undefined {
  return getPoems().find((p) => p.id === id);
}
