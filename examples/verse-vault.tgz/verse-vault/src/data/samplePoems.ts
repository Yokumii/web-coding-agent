import type { Poem } from '../types/poem';

export const samplePoems: Poem[] = [
  {
    id: '1',
    title: 'The Road Not Taken',
    author: 'Robert Frost',
    body: `Two roads diverged in a yellow wood,
And sorry I could not travel both
And be one traveler, long I stood
And looked down one as far as I could
To where it bent in the undergrowth;

Then took the other, as just as fair,
And having perhaps the better claim,
Because it was grassy and wanted wear;
Though as for that the passing there
Had worn them really about the same,

And both that morning equally lay
In leaves no step had trodden black.
Oh, I kept the first for another day!
Yet knowing how way leads on to way,
I doubted if I should ever come back.

I shall be telling this with a sigh
Somewhere ages and ages hence:
Two roads diverged in a wood, and I—
I took the one less traveled by,
And that has made all the difference.`,
    category: 'Free Verse',
    date: '1916-03-01',
  },
  {
    id: '2',
    title: 'Sonnet 18',
    author: 'William Shakespeare',
    body: `Shall I compare thee to a summer's day?
Thou art more lovely and more temperate:
Rough winds do shake the darling buds of May,
And summer's lease hath all too short a date;
Sometime too hot the eye of heaven shines,
And often is his gold complexion dimm'd;
And every fair from fair sometime declines,
By chance or nature's changing course untrimm'd;
But thy eternal summer shall not fade
Nor lose possession of that fair thou ow'st;
Nor shall Death brag thou wander'st in his shade,
When in eternal lines to time thou grow'st:
So long as men can breathe or eyes can see,
So long lives this, and this gives life to thee.`,
    category: 'Sonnet',
    date: '1609-01-01',
  },
  {
    id: '3',
    title: 'The Owl and the Pussycat',
    author: 'Edward Lear',
    body: `The Owl and the Pussy-cat went to sea
In a beautiful pea-green boat,
They took some honey, and plenty of money,
Wrapped up in a five-pound note.
The Owl looked up to the stars above,
And sang to a small guitar,
"O lovely Pussy! O Pussy, my love,
What a beautiful Pussy you are,
You are,
What a beautiful Pussy you are!"

Pussy said to the Owl, "You elegant fowl!
How charmingly sweet you sing!
O let us be married! too long we have tarried:
But what shall we do for a ring?"
They sailed away, for a year and a day,
To the land where the Bong-tree grows
And there in a wood a Piggy-wig stood
With a ring at the end of his nose,
His nose,
With a ring at the end of his nose.`,
    category: 'Limerick',
    date: '1871-01-01',
  },
  {
    id: '4',
    title: 'Haiku Moment',
    author: 'Matsuo Basho',
    body: `Old silent pond...
A frog jumps into the pond—
Splash! Silence again.`,
    category: 'Haiku',
    date: '1686-01-01',
  },
  {
    id: '5',
    title: 'Ode to a Nightingale',
    author: 'John Keats',
    body: `My heart aches, and a drowsy numbness pains
My sense, as though of hemlock I had drunk,
Or emptied some dull opiate to the drains
One minute past, and Lethe-wards had sunk:
'Tis not through envy of thy happy lot,
But being too happy in thine happiness,—
That thou, light-winged Dryad of the trees
In some melodious plot
Of beechen green, and shadows numberless,
Singest of summer in full-throated ease.`,
    category: 'Ballad',
    date: '1819-05-01',
  },
  {
    id: '6',
    title: 'Hope is the thing with feathers',
    author: 'Emily Dickinson',
    body: `Hope is the thing with feathers -
That perches in the soul -
And sings the tune without the words -
And never stops - at all -

And sweetest - in the Gale - is heard -
And sore must be the storm -
That could abash the little Bird
That kept so many warm -

I've heard it in the chillest land -
And on the strangest Sea -
Yet - never - in Extremity,
It asked a crumb - of me.`,
    category: 'Free Verse',
    date: '1891-01-01',
  },
];
