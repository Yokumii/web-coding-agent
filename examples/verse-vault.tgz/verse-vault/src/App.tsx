import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import PoemDetailPage from './pages/PoemDetailPage';
import PostPoemPage from './pages/PostPoemPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="poem/:id" element={<PoemDetailPage />} />
          <Route path="post" element={<PostPoemPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
