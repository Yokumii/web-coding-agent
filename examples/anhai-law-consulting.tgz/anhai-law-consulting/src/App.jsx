import { Routes, Route } from 'react-router-dom'
import Nav from './components/Nav'
import Footer from './components/Footer'
import ScrollToTop from './components/ScrollToTop'
import Hero from './pages/Hero'
import CompanyIntroduction from './pages/CompanyIntroduction'
import Services from './pages/Services'
import News from './pages/News'
import Contact from './pages/Contact'

function App() {
  return (
    <>
      <ScrollToTop />
      <Nav />
      <main style={{ flex: '1 0 auto' }}>
        <Routes>
          <Route path="/" element={<Hero />} />
          <Route path="/about" element={<CompanyIntroduction />} />
          <Route path="/services" element={<Services />} />
          <Route path="/news" element={<News />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>
      <Footer />
    </>
  )
}

export default App
