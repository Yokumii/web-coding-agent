import { useState, useEffect } from 'react';
import Container from '../components/Container';
import Section from '../components/Section';
import Card from '../components/Card';
import Button from '../components/Button';
import FadeIn from '../components/FadeIn';

const STORAGE_KEY = 'anhai_contact_form_draft';

const contactInfo = {
  address: {
    label: 'Address',
    value: "Anhai Professional Law Firm\n128 Chang'an Avenue, Dongcheng District\nBeijing, 100006, China",
  },
  phone: {
    label: 'Phone',
    value: '+86 (10) 8888-1234',
  },
  email: {
    label: 'Email',
    value: 'contact@anhai-professional.com',
  },
  hours: {
    label: 'Business Hours',
    value: 'Monday – Friday: 9:00 AM – 6:00 PM CST\nSaturday: 10:00 AM – 2:00 PM CST\nSunday: Closed',
  },
};

const initialFormState = {
  name: '',
  email: '',
  subject: '',
  message: '',
};

export default function Contact() {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');
  const [touched, setTouched] = useState({});

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          setFormData((prev) => ({ ...prev, ...parsed }));
        }
      }
    } catch {
      // Ignore invalid localStorage data
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
    } catch {
      // Ignore localStorage errors
    }
  }, [formData]);

  const validate = (data) => {
    const newErrors = {};
    if (!data.name.trim()) {
      newErrors.name = 'Name is required';
    }
    if (!data.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!data.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }
    if (!data.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (data.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters';
    }
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const fieldErrors = validate({ ...formData, [name]: formData[name] });
    if (fieldErrors[name]) {
      setErrors((prev) => ({ ...prev, [name]: fieldErrors[name] }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate(formData);
    setErrors(validationErrors);
    setTouched({ name: true, email: true, subject: true, message: true });

    if (Object.keys(validationErrors).length > 0) {
      setStatus('error');
      return;
    }

    setStatus('submitting');

    setTimeout(() => {
      setStatus('success');
      setFormData(initialFormState);
      setTouched({});
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        // Ignore localStorage errors
      }
    }, 1500);
  };

  const handleReset = () => {
    setFormData(initialFormState);
    setErrors({});
    setTouched({});
    setStatus('idle');
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore localStorage errors
    }
  };

  return (
    <>
      {/* Page Header */}
      <Section bg="primary" padding="lg">
        <Container>
          <div
            style={{
              textAlign: 'center',
              paddingTop: 'var(--space-8)',
              paddingBottom: 'var(--space-6)',
            }}
          >
            <FadeIn>
              <h1
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(var(--size-3xl), 6vw, var(--size-5xl))',
                  fontWeight: 'var(--weight-bold)',
                  color: 'var(--color-fg-primary)',
                  lineHeight: 'var(--line-height-tight)',
                  marginBottom: 'var(--space-5)',
                }}
              >
                Contact Us
              </h1>
            </FadeIn>
            <FadeIn delay={100}>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(var(--size-lg), 2vw, var(--size-xl))',
                  color: 'var(--color-fg-secondary)',
                  maxWidth: '720px',
                  margin: '0 auto',
                  lineHeight: 'var(--line-height-relaxed)',
                }}
              >
                We welcome your inquiries. Reach out to discuss how Anhai
                Professional can assist with your legal needs.
              </p>
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* Contact Info & Form */}
      <Section bg="secondary" padding="lg">
        <Container>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-7)',
              alignItems: 'start',
            }}
          >
            {/* Contact Information */}
            <FadeIn>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 'var(--space-5)',
                }}
              >
                <h2
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-2xl)',
                    fontWeight: 'var(--weight-semibold)',
                    color: 'var(--color-fg-primary)',
                    marginBottom: 'var(--space-2)',
                  }}
                >
                  Get in Touch
                </h2>

                <ContactCard
                  label={contactInfo.address.label}
                  value={contactInfo.address.value}
                  icon={<MapPinIcon />}
                />
                <ContactCard
                  label={contactInfo.phone.label}
                  value={contactInfo.phone.value}
                  icon={<PhoneIcon />}
                  href={`tel:${contactInfo.phone.value.replace(/[^\d+]/g, '')}`}
                />
                <ContactCard
                  label={contactInfo.email.label}
                  value={contactInfo.email.value}
                  icon={<MailIcon />}
                  href={`mailto:${contactInfo.email.value}`}
                />
                <ContactCard
                  label={contactInfo.hours.label}
                  value={contactInfo.hours.value}
                  icon={<ClockIcon />}
                />
              </div>
            </FadeIn>

            {/* Contact Form */}
            <FadeIn delay={150}>
              <Card
                variant="default"
                style={{
                  width: '100%',
                }}
              >
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-xl)',
                    fontWeight: 'var(--weight-semibold)',
                    color: 'var(--color-fg-primary)',
                    marginBottom: 'var(--space-5)',
                  }}
                >
                  Send an Inquiry
                </h3>

                {status === 'success' ? (
                  <div
                    style={{
                      textAlign: 'center',
                      padding: 'var(--space-6)',
                    }}
                  >
                    <div
                      style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '50%',
                        backgroundColor: 'var(--color-success)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto var(--space-5)',
                      }}
                    >
                      <CheckIcon />
                    </div>
                    <h4
                      style={{
                        fontFamily: 'var(--font-heading)',
                        fontSize: 'var(--size-xl)',
                        fontWeight: 'var(--weight-semibold)',
                        color: 'var(--color-fg-primary)',
                        marginBottom: 'var(--space-3)',
                      }}
                    >
                      Message Sent
                    </h4>
                    <p
                      style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--size-base)',
                        color: 'var(--color-fg-secondary)',
                        lineHeight: 'var(--line-height-relaxed)',
                        marginBottom: 'var(--space-5)',
                      }}
                    >
                      Thank you for reaching out. Our team will review your
                      inquiry and respond within 24 business hours.
                    </p>
                    <Button variant="secondary" size="md" onClick={handleReset}>
                      Send Another Message
                    </Button>
                  </div>
                ) : (
                  <form
                    onSubmit={handleSubmit}
                    noValidate
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: 'var(--space-4)',
                    }}
                  >
                    <FormField
                      label="Name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={errors.name}
                      touched={touched.name}
                      placeholder="Your full name"
                      autoComplete="name"
                    />

                    <FormField
                      label="Email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={errors.email}
                      touched={touched.email}
                      placeholder="your.email@example.com"
                      autoComplete="email"
                    />

                    <FormField
                      label="Subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={errors.subject}
                      touched={touched.subject}
                      placeholder="How can we help?"
                    />

                    <FormField
                      label="Message"
                      name="message"
                      as="textarea"
                      value={formData.message}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={errors.message}
                      touched={touched.message}
                      placeholder="Please describe your inquiry in detail..."
                      rows={5}
                    />

                    {status === 'error' && (
                      <div
                        style={{
                          padding: 'var(--space-3) var(--space-4)',
                          borderRadius: 'var(--radius-md)',
                          backgroundColor: 'rgba(139, 0, 0, 0.08)',
                          border: '1px solid var(--color-error)',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 'var(--space-2)',
                        }}
                      >
                        <AlertIcon />
                        <span
                          style={{
                            fontFamily: 'var(--font-body)',
                            fontSize: 'var(--size-sm)',
                            color: 'var(--color-error)',
                          }}
                        >
                          Please correct the errors above before submitting.
                        </span>
                      </div>
                    )}

                    <div
                      style={{
                        display: 'flex',
                        gap: 'var(--space-3)',
                        flexWrap: 'wrap',
                        marginTop: 'var(--space-2)',
                      }}
                    >
                      <Button
                        type="submit"
                        variant="primary"
                        size="md"
                        disabled={status === 'submitting'}
                      >
                        {status === 'submitting'
                          ? 'Sending...'
                          : 'Send Message'}
                      </Button>
                      <Button
                        type="button"
                        variant="secondary"
                        size="md"
                        onClick={handleReset}
                      >
                        Clear
                      </Button>
                    </div>
                  </form>
                )}
              </Card>
            </FadeIn>
          </div>
        </Container>
      </Section>
    </>
  );
}

function ContactCard({ label, value, icon, href }) {
  const content = (
    <div
      style={{
        display: 'flex',
        gap: 'var(--space-4)',
        alignItems: 'flex-start',
      }}
    >
      <div
        style={{
          flexShrink: 0,
          width: '40px',
          height: '40px',
          borderRadius: 'var(--radius-md)',
          backgroundColor: 'var(--color-bg-primary)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--color-accent)',
        }}
      >
        {icon}
      </div>
      <div>
        <p
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--size-xs)',
            fontWeight: 'var(--weight-semibold)',
            letterSpacing: 'var(--letter-spacing-wide)',
            textTransform: 'uppercase',
            color: 'var(--color-fg-secondary)',
            marginBottom: 'var(--space-1)',
          }}
        >
          {label}
        </p>
        <p
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--size-base)',
            color: 'var(--color-fg-primary)',
            lineHeight: 'var(--line-height-relaxed)',
            whiteSpace: 'pre-line',
          }}
        >
          {value}
        </p>
      </div>
    </div>
  );

  if (href) {
    return (
      <a
        href={href}
        style={{
          textDecoration: 'none',
          display: 'block',
        }}
      >
        <Card
          variant="default"
          style={{
            cursor: 'pointer',
            transition: 'all var(--duration-normal) ease-in-out',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = 'var(--color-accent)';
            e.currentTarget.style.transform = 'translateY(-2px)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = 'var(--color-border-light)';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          {content}
        </Card>
      </a>
    );
  }

  return <Card variant="default">{content}</Card>;
}

function FormField({
  label,
  name,
  error,
  touched,
  as: Component = 'input',
  ...props
}) {
  const hasError = error && touched;

  const inputStyle = {
    width: '100%',
    padding: 'var(--space-3) var(--space-4)',
    borderRadius: 'var(--radius-md)',
    border: hasError
      ? '1px solid var(--color-error)'
      : '1px solid var(--color-border-light)',
    backgroundColor: 'var(--color-bg-primary)',
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--size-base)',
    color: 'var(--color-fg-primary)',
    outline: 'none',
    transition: 'border-color var(--duration-fast) ease-out, box-shadow var(--duration-fast) ease-out',
    resize: Component === 'textarea' ? 'vertical' : 'none',
  };

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 'var(--space-2)',
      }}
    >
      <label
        htmlFor={name}
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-sm)',
          fontWeight: 'var(--weight-medium)',
          color: 'var(--color-fg-primary)',
        }}
      >
        {label}
      </label>
      <Component id={name} name={name} style={inputStyle} {...props} />
      {hasError && (
        <span
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--size-xs)',
            color: 'var(--color-error)',
            display: 'flex',
            alignItems: 'center',
            gap: 'var(--space-1)',
          }}
        >
          {error}
        </span>
      )}
    </div>
  );
}

/* SVG Icons */

function MapPinIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a12 12 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
    </svg>
  );
}

function MailIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="16" x="2" y="4" rx="2" />
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
    </svg>
  );
}

function ClockIcon() {
  return (
      <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="#fff"
      strokeWidth="3"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

function AlertIcon() {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="var(--color-error)"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" x2="12" y1="8" y2="12" />
      <line x1="12" x2="12.01" y1="16" y2="16" />
    </svg>
  );
}
