import Container from '../components/Container';
import Button from '../components/Button';
import Section from '../components/Section';
import Card from '../components/Card';
import FadeIn from '../components/FadeIn';

export default function Hero() {
  return (
    <>
      <div
        id="hero"
        style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'var(--color-bg-primary)',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Decorative accent line */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: '50%',
            transform: 'translateX(-50%)',
            width: '1px',
            height: '80px',
            backgroundColor: 'var(--color-accent)',
            opacity: 0.4,
          }}
        />

        <Container
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            textAlign: 'center',
            paddingTop: 'var(--space-10)',
            paddingBottom: 'var(--space-10)',
          }}
        >
          <FadeIn delay={0}>
            {/* Firm name */}
            <h1
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(var(--size-4xl), 8vw, var(--size-6xl))',
                fontWeight: 'var(--weight-bold)',
                color: 'var(--color-fg-primary)',
                lineHeight: 'var(--line-height-tight)',
                letterSpacing: 'var(--letter-spacing-tight)',
                marginBottom: 'var(--space-5)',
              }}
            >
              Anhai Professional
            </h1>
          </FadeIn>

          <FadeIn delay={100}>
            {/* Tagline */}
            <p
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'clamp(var(--size-lg), 2.5vw, var(--size-2xl))',
                fontWeight: 'var(--weight-normal)',
                color: 'var(--color-fg-secondary)',
                lineHeight: 'var(--line-height-normal)',
                maxWidth: '640px',
                marginBottom: 'var(--space-8)',
              }}
            >
              Expertise in International Trade Law, Corporate Advisory,
              and Cross-Border Dispute Resolution
            </p>
          </FadeIn>

          <FadeIn delay={200}>
            {/* Decorative divider */}
            <div
              style={{
                width: '60px',
                height: '2px',
                backgroundColor: 'var(--color-accent)',
                marginBottom: 'var(--space-8)',
              }}
            />
          </FadeIn>

          <FadeIn delay={300}>
            {/* CTA Buttons */}
            <div
              style={{
                display: 'flex',
                gap: 'var(--space-4)',
                flexWrap: 'wrap',
                justifyContent: 'center',
              }}
            >
              <Button to="/services" variant="primary" size="lg">
                Our Services
              </Button>
              <Button to="/contact" variant="secondary" size="lg">
                Contact Us
              </Button>
            </div>
          </FadeIn>
        </Container>

        {/* Scroll indicator */}
        <a
          href="#expertise"
          style={{
            position: 'absolute',
            bottom: 'var(--space-7)',
            left: '50%',
            transform: 'translateX(-50%)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 'var(--space-2)',
            textDecoration: 'none',
            cursor: 'pointer',
          }}
          aria-label="Scroll to expertise section"
        >
          <span
            style={{
              fontSize: 'var(--size-xs)',
              fontWeight: 'var(--weight-medium)',
              letterSpacing: 'var(--letter-spacing-wide)',
              textTransform: 'uppercase',
              color: 'var(--color-fg-secondary)',
            }}
          >
            Scroll
          </span>
          <div
            style={{
              width: '1px',
              height: '32px',
              backgroundColor: 'var(--color-border)',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            <div
              style={{
                width: '100%',
                height: '50%',
                backgroundColor: 'var(--color-accent)',
                animation: 'scrollPulse 2s ease-in-out infinite',
              }}
            />
          </div>
        </a>
      </div>

      {/* Highlights section with light Cards */}
      <Section id="expertise" bg="secondary" padding="lg">
        <Container>
          <FadeIn>
            <h2
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'var(--size-3xl)',
                textAlign: 'center',
                marginBottom: 'var(--space-6)',
              }}
            >
              Our Expertise
            </h2>
          </FadeIn>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-5)',
            }}
          >
            <FadeIn delay={0}>
              <Card>
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-xl)',
                    marginBottom: 'var(--space-3)',
                  }}
                >
                  International Trade
                </h3>
                <p>
                  Comprehensive counsel on cross-border transactions, customs compliance, and trade regulation.
                </p>
              </Card>
            </FadeIn>
            <FadeIn delay={100}>
              <Card>
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-xl)',
                    marginBottom: 'var(--space-3)',
                  }}
                >
                  Corporate Advisory
                </h3>
                <p>
                  Strategic guidance on mergers, acquisitions, and corporate governance for global enterprises.
                </p>
              </Card>
            </FadeIn>
            <FadeIn delay={200}>
              <Card>
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-xl)',
                    marginBottom: 'var(--space-3)',
                  }}
                >
                  Dispute Resolution
                </h3>
                <p>
                  Skilled representation in arbitration and litigation across multiple jurisdictions.
                </p>
              </Card>
            </FadeIn>
          </div>
          <div
            style={{
              textAlign: 'center',
              marginTop: 'var(--space-6)',
            }}
          >
            <a
              href="#testimonials"
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-sm)',
                color: 'var(--color-accent)',
                textDecoration: 'none',
                letterSpacing: 'var(--letter-spacing-wide)',
                textTransform: 'uppercase',
                fontWeight: 'var(--weight-medium)',
                transition: 'color var(--duration-fast) ease-out',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-accent-hover)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-accent)';
              }}
            >
              View Testimonials &darr;
            </a>
          </div>
        </Container>
      </Section>

      {/* Dark context demonstration */}
      <Section id="testimonials" bg="dark" padding="lg">
        <Container>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-5)',
              alignItems: 'start',
            }}
          >
            <FadeIn>
              <Card variant="dark">
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-xl)',
                    marginBottom: 'var(--space-3)',
                  }}
                >
                  Client Testimonial
                </h3>
                <p>
                  &ldquo;Anhai Professional provided exceptional guidance during our international expansion. Their expertise in cross-border regulations was invaluable.&rdquo;
                </p>
                <p
                  style={{
                    marginTop: 'var(--space-4)',
                    fontWeight: 'var(--weight-medium)',
                  }}
                >
                  &mdash; Senior Counsel, Global Tech Inc.
                </p>
              </Card>
            </FadeIn>
            <FadeIn delay={150}>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  gap: 'var(--space-4)',
                }}
              >
                <h2
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-3xl)',
                    color: 'var(--color-fg-on-dark)',
                  }}
                >
                  Trusted by Leading Firms
                </h2>
                <p style={{ color: 'var(--color-fg-on-dark)' }}>
                  Our clients rely on us for complex, high-stakes matters that demand precision, discretion, and deep legal expertise.
                </p>
                <Button to="/contact" variant="outline" size="md">
                  Get in Touch
                </Button>
                <a
                  href="#hero"
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--size-sm)',
                    color: 'var(--color-fg-on-dark)',
                    textDecoration: 'none',
                    letterSpacing: 'var(--letter-spacing-wide)',
                    textTransform: 'uppercase',
                    fontWeight: 'var(--weight-medium)',
                    opacity: 0.8,
                    transition: 'opacity var(--duration-fast) ease-out, color var(--duration-fast) ease-out',
                    cursor: 'pointer',
                    marginTop: 'var(--space-2)',
                    display: 'inline-block',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.opacity = '1';
                    e.currentTarget.style.color = 'var(--color-accent)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.opacity = '0.8';
                    e.currentTarget.style.color = 'var(--color-fg-on-dark)';
                  }}
                >
                  Back to Top &uarr;
                </a>
              </div>
            </FadeIn>
          </div>
        </Container>
      </Section>
    </>
  );
}
