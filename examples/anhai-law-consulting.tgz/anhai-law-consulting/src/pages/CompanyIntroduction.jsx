import Container from '../components/Container';
import Section from '../components/Section';
import FadeIn from '../components/FadeIn';

export default function CompanyIntroduction() {
  return (
    <>
      {/* Page Header */}
      <Section bg="primary" padding="lg">
        <Container>
          <div
            style={{
              textAlign: 'center',
              paddingTop: 'var(--space-8)',
              paddingBottom: 'var(--space-6)',
            }}
          >
            <FadeIn>
              <h1
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(var(--size-3xl), 6vw, var(--size-5xl))',
                  fontWeight: 'var(--weight-bold)',
                  color: 'var(--color-fg-primary)',
                  lineHeight: 'var(--line-height-tight)',
                  marginBottom: 'var(--space-5)',
                }}
              >
                About Anhai Professional
              </h1>
            </FadeIn>
            <FadeIn delay={100}>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(var(--size-lg), 2vw, var(--size-xl))',
                  color: 'var(--color-fg-secondary)',
                  maxWidth: '720px',
                  margin: '0 auto',
                  lineHeight: 'var(--line-height-relaxed)',
                }}
              >
                A legacy of legal excellence spanning over two decades, dedicated to
                serving clients with integrity, precision, and global perspective.
              </p>
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* History Section - Dark Block */}
      <Section bg="dark" padding="lg">
        <Container>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-8)',
              alignItems: 'center',
            }}
          >
            <FadeIn>
              <div>
                <h2
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-3xl)',
                    color: 'var(--color-fg-on-dark)',
                    marginBottom: 'var(--space-5)',
                    lineHeight: 'var(--line-height-tight)',
                  }}
                >
                  Our History
                </h2>
                <div
                  style={{
                    width: '60px',
                    height: '2px',
                    backgroundColor: 'var(--color-accent)',
                    marginBottom: 'var(--space-5)',
                  }}
                />
                <p
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--size-lg)',
                    color: 'var(--color-fg-on-dark)',
                    lineHeight: 'var(--line-height-relaxed)',
                    marginBottom: 'var(--space-4)',
                  }}
                >
                  Founded in 2003, Anhai Professional began as a boutique firm
                  specializing in international trade law. Over the past two decades,
                  we have grown into a full-service legal practice with offices across
                  three continents.
                </p>
                <p
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--size-base)',
                    color: 'var(--color-fg-on-dark)',
                    lineHeight: 'var(--line-height-relaxed)',
                    opacity: 0.9,
                  }}
                >
                  Our journey has been marked by landmark cases, enduring client
                  relationships, and a steadfast commitment to excellence that continues
                  to define our practice today.
                </p>
              </div>
            </FadeIn>
            <FadeIn delay={150}>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(2, 1fr)',
                  gap: 'var(--space-5)',
                }}
              >
                <StatCard number="20+" label="Years of Excellence" />
                <StatCard number="500+" label="Clients Served" />
                <StatCard number="35+" label="Legal Professionals" />
                <StatCard number="12" label="Global Jurisdictions" />
              </div>
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* Mission Section */}
      <Section bg="primary" padding="lg">
        <Container>
          <FadeIn>
            <div
              style={{
                textAlign: 'center',
                maxWidth: '800px',
                margin: '0 auto',
              }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'var(--size-3xl)',
                  color: 'var(--color-fg-primary)',
                  marginBottom: 'var(--space-5)',
                  lineHeight: 'var(--line-height-tight)',
                }}
              >
                Our Mission
              </h2>
              <div
                style={{
                  width: '60px',
                  height: '2px',
                  backgroundColor: 'var(--color-accent)',
                  margin: '0 auto var(--space-6)',
                }}
              />
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(var(--size-lg), 2vw, var(--size-xl))',
                  color: 'var(--color-fg-secondary)',
                  lineHeight: 'var(--line-height-relaxed)',
                  marginBottom: 'var(--space-6)',
                }}
              >
                To deliver world-class legal counsel that empowers businesses and
                individuals to navigate complex global challenges with confidence,
                clarity, and unwavering ethical standards.
              </p>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'var(--size-base)',
                  color: 'var(--color-fg-secondary)',
                  lineHeight: 'var(--line-height-relaxed)',
                }}
              >
                We believe that exceptional legal representation is built on trust,
                deep expertise, and a genuine understanding of our clients&rsquo;
                objectives. Every matter we undertake receives the full measure of our
                dedication and strategic insight.
              </p>
            </div>
          </FadeIn>
        </Container>
      </Section>

      {/* Core Values Section - Dark Block */}
      <Section bg="dark" padding="lg">
        <Container>
          <FadeIn>
            <div style={{ textAlign: 'center', marginBottom: 'var(--space-8)' }}>
              <h2
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'var(--size-3xl)',
                  color: 'var(--color-fg-on-dark)',
                  marginBottom: 'var(--space-5)',
                  lineHeight: 'var(--line-height-tight)',
                }}
              >
                Core Values
              </h2>
              <div
                style={{
                  width: '60px',
                  height: '2px',
                  backgroundColor: 'var(--color-accent)',
                  margin: '0 auto',
                }}
              />
            </div>
          </FadeIn>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-5)',
            }}
          >
            <FadeIn delay={0}>
              <ValueCard
                title="Integrity"
                description="We uphold the highest ethical standards in every engagement, ensuring transparency and honesty in all our dealings."
              />
            </FadeIn>
            <FadeIn delay={100}>
              <ValueCard
                title="Excellence"
                description="We pursue perfection in our legal work, combining rigorous analysis with creative problem-solving to achieve optimal outcomes."
              />
            </FadeIn>
            <FadeIn delay={200}>
              <ValueCard
                title="Client Focus"
                description="We place our clients at the center of everything we do, tailoring our approach to their unique needs and aspirations."
              />
            </FadeIn>
            <FadeIn delay={300}>
              <ValueCard
                title="Global Perspective"
                description="We bring a worldwide outlook to every matter, leveraging our international network to deliver comprehensive solutions."
              />
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* Team Credentials & International Presence */}
      <Section bg="primary" padding="lg">
        <Container>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-8)',
              alignItems: 'start',
            }}
          >
            <FadeIn>
              <div>
                <h2
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-3xl)',
                    color: 'var(--color-fg-primary)',
                    marginBottom: 'var(--space-5)',
                    lineHeight: 'var(--line-height-tight)',
                  }}
                >
                  Team Credentials
                </h2>
                <div
                  style={{
                    width: '60px',
                    height: '2px',
                    backgroundColor: 'var(--color-accent)',
                    marginBottom: 'var(--space-5)',
                  }}
                />
                <p
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--size-base)',
                    color: 'var(--color-fg-secondary)',
                    lineHeight: 'var(--line-height-relaxed)',
                    marginBottom: 'var(--space-5)',
                  }}
                >
                  Our team comprises seasoned attorneys and legal professionals with
                  qualifications from leading institutions worldwide. Many of our
                  partners hold advanced degrees from Harvard, Oxford, and Tsinghua
                  University.
                </p>
                <ul
                  style={{
                    listStyle: 'none',
                    padding: 0,
                    margin: 0,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'var(--space-3)',
                  }}
                >
                  <CredentialItem text="Senior partners with 25+ years of experience" />
                  <CredentialItem text="Admitted to practice in multiple jurisdictions" />
                  <CredentialItem text="Former judicial clerks and government advisors" />
                  <CredentialItem text="Published authors in international law journals" />
                </ul>
              </div>
            </FadeIn>
            <FadeIn delay={150}>
              <div>
                <h2
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 'var(--size-3xl)',
                    color: 'var(--color-fg-primary)',
                    marginBottom: 'var(--space-5)',
                    lineHeight: 'var(--line-height-tight)',
                  }}
                >
                  International Presence
                </h2>
                <div
                  style={{
                    width: '60px',
                    height: '2px',
                    backgroundColor: 'var(--color-accent)',
                    marginBottom: 'var(--space-5)',
                  }}
                />
                <p
                  style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--size-base)',
                    color: 'var(--color-fg-secondary)',
                    lineHeight: 'var(--line-height-relaxed)',
                    marginBottom: 'var(--space-5)',
                  }}
                >
                  With offices in Beijing, London, and Singapore, Anhai Professional
                  maintains a strategic global footprint that enables us to serve
                  clients across time zones and legal systems.
                </p>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                    gap: 'var(--space-4)',
                  }}
                >
                  <OfficeCard city="Beijing" role="Asia-Pacific Headquarters" />
                  <OfficeCard city="London" role="European Operations" />
                  <OfficeCard city="Singapore" role="Southeast Asia Hub" />
                </div>
              </div>
            </FadeIn>
          </div>
        </Container>
      </Section>
    </>
  );
}

function StatCard({ number, label }) {
  return (
    <div
      style={{
        textAlign: 'center',
        padding: 'var(--space-6)',
        border: '1px solid rgba(255, 235, 205, 0.2)',
        borderRadius: 'var(--radius-lg)',
      }}
    >
      <div
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'var(--size-4xl)',
          fontWeight: 'var(--weight-bold)',
          color: 'var(--color-accent)',
          lineHeight: 'var(--line-height-tight)',
          marginBottom: 'var(--space-2)',
        }}
      >
        {number}
      </div>
      <div
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-sm)',
          color: 'var(--color-fg-on-dark)',
          letterSpacing: 'var(--letter-spacing-wide)',
          textTransform: 'uppercase',
        }}
      >
        {label}
      </div>
    </div>
  );
}

function ValueCard({ title, description }) {
  return (
    <div
      style={{
        padding: 'var(--space-6)',
        border: '1px solid rgba(255, 235, 205, 0.15)',
        borderRadius: 'var(--radius-lg)',
        backgroundColor: 'rgba(255, 235, 205, 0.05)',
        transition: 'all var(--duration-normal) ease-in-out',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = 'rgba(255, 235, 205, 0.1)';
        e.currentTarget.style.borderColor = 'rgba(255, 235, 205, 0.3)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = 'rgba(255, 235, 205, 0.05)';
        e.currentTarget.style.borderColor = 'rgba(255, 235, 205, 0.15)';
      }}
    >
      <h3
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'var(--size-xl)',
          color: 'var(--color-fg-on-dark)',
          marginBottom: 'var(--space-3)',
          lineHeight: 'var(--line-height-tight)',
        }}
      >
        {title}
      </h3>
      <p
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-base)',
          color: 'var(--color-fg-on-dark)',
          lineHeight: 'var(--line-height-relaxed)',
          opacity: 0.85,
        }}
      >
        {description}
      </p>
    </div>
  );
}

function CredentialItem({ text }) {
  return (
    <li
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 'var(--space-3)',
      }}
    >
      <span
        style={{
          width: '8px',
          height: '8px',
          minWidth: '8px',
          borderRadius: '50%',
          backgroundColor: 'var(--color-accent)',
          marginTop: '8px',
        }}
      />
      <span
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-base)',
          color: 'var(--color-fg-secondary)',
          lineHeight: 'var(--line-height-relaxed)',
        }}
      >
        {text}
      </span>
    </li>
  );
}

function OfficeCard({ city, role }) {
  return (
    <div
      style={{
        padding: 'var(--space-5)',
        border: '1px solid var(--color-border-light)',
        borderRadius: 'var(--radius-lg)',
        backgroundColor: 'var(--color-bg-secondary)',
      }}
    >
      <h4
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'var(--size-lg)',
          color: 'var(--color-fg-primary)',
          marginBottom: 'var(--space-1)',
          lineHeight: 'var(--line-height-tight)',
        }}
      >
        {city}
      </h4>
      <p
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-sm)',
          color: 'var(--color-fg-secondary)',
          lineHeight: 'var(--line-height-normal)',
        }}
      >
        {role}
      </p>
    </div>
  );
}
