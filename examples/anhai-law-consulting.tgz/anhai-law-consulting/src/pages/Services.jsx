import Container from '../components/Container';
import Section from '../components/Section';
import Card from '../components/Card';
import Button from '../components/Button';
import FadeIn from '../components/FadeIn';

const serviceCategories = [
  {
    title: 'International Trade Law',
    description:
      'Navigate complex cross-border transactions with confidence. Our trade law practice covers customs compliance, export controls, sanctions, and bilateral trade agreements.',
    details: [
      'Customs & tariff compliance',
      'Export control & sanctions',
      'WTO dispute resolution',
      'Bilateral trade agreements',
    ],
  },
  {
    title: 'Corporate Law',
    description:
      'Strategic counsel for mergers, acquisitions, and corporate governance. We guide enterprises through complex transactions with precision and discretion.',
    details: [
      'Mergers & acquisitions',
      'Corporate governance',
      'Due diligence',
      'Regulatory compliance',
    ],
  },
  {
    title: 'Intellectual Property',
    description:
      'Protect your innovations and creative assets across jurisdictions. Our IP practice covers patents, trademarks, copyrights, and trade secrets.',
    details: [
      'Patent prosecution & litigation',
      'Trademark registration',
      'Copyright enforcement',
      'Trade secret protection',
    ],
  },
  {
    title: 'Dispute Resolution',
    description:
      'Skilled representation in arbitration and litigation across multiple jurisdictions. We resolve complex disputes efficiently and effectively.',
    details: [
      'International arbitration',
      'Commercial litigation',
      'Mediation & settlement',
      'Enforcement of awards',
    ],
  },
  {
    title: 'Immigration Services',
    description:
      'Comprehensive immigration counsel for businesses and individuals. We navigate visa applications, work permits, and citizenship matters.',
    details: [
      'Business visas & work permits',
      'Family-based immigration',
      'Citizenship & naturalization',
      'Compliance & audits',
    ],
  },
];

export default function Services() {
  return (
    <>
      {/* Page Header */}
      <Section bg="primary" padding="lg">
        <Container>
          <div
            style={{
              textAlign: 'center',
              paddingTop: 'var(--space-8)',
              paddingBottom: 'var(--space-6)',
            }}
          >
            <FadeIn>
              <h1
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(var(--size-3xl), 6vw, var(--size-5xl))',
                  fontWeight: 'var(--weight-bold)',
                  color: 'var(--color-fg-primary)',
                  lineHeight: 'var(--line-height-tight)',
                  marginBottom: 'var(--space-5)',
                }}
              >
                Our Services
              </h1>
            </FadeIn>
            <FadeIn delay={100}>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(var(--size-lg), 2vw, var(--size-xl))',
                  color: 'var(--color-fg-secondary)',
                  maxWidth: '720px',
                  margin: '0 auto',
                  lineHeight: 'var(--line-height-relaxed)',
                }}
              >
                Comprehensive legal solutions tailored to your business needs.
                Our multidisciplinary practice delivers strategic counsel across
                five core service areas.
              </p>
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* Service Categories Grid */}
      <Section bg="secondary" padding="lg">
        <Container>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 'var(--space-5)',
            }}
          >
            {serviceCategories.map((service, index) => (
              <FadeIn key={service.title} delay={index * 100}>
                <ServiceCard service={service} />
              </FadeIn>
            ))}
          </div>
        </Container>
      </Section>

      {/* Dark CTA Section */}
      <Section bg="dark" padding="lg">
        <Container>
          <FadeIn>
            <div
              style={{
                textAlign: 'center',
                maxWidth: '700px',
                margin: '0 auto',
              }}
            >
              <h2
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(var(--size-2xl), 4vw, var(--size-3xl))',
                  color: 'var(--color-fg-on-dark)',
                  marginBottom: 'var(--space-5)',
                  lineHeight: 'var(--line-height-tight)',
                }}
              >
                Need Expert Legal Guidance?
              </h2>
              <div
                style={{
                  width: '60px',
                  height: '2px',
                  backgroundColor: 'var(--color-accent)',
                  margin: '0 auto var(--space-6)',
                }}
              />
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'var(--size-lg)',
                  color: 'var(--color-fg-on-dark)',
                  lineHeight: 'var(--line-height-relaxed)',
                  marginBottom: 'var(--space-7)',
                  opacity: 0.9,
                }}
              >
                Our team of experienced attorneys is ready to assist you with
                complex legal matters. Reach out today to discuss how we can
                support your objectives.
              </p>
              <Button to="/contact" variant="outline" size="lg">
                Contact Us
              </Button>
            </div>
          </FadeIn>
        </Container>
      </Section>
    </>
  );
}

function ServiceCard({ service }) {
  return (
    <Card
      variant="default"
      style={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <h3
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'var(--size-xl)',
          color: 'var(--color-fg-primary)',
          marginBottom: 'var(--space-3)',
          lineHeight: 'var(--line-height-tight)',
        }}
      >
        {service.title}
      </h3>
      <p
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-base)',
          color: 'var(--color-fg-secondary)',
          lineHeight: 'var(--line-height-relaxed)',
          marginBottom: 'var(--space-4)',
          flex: '1',
        }}
      >
        {service.description}
      </p>
      <ul
        style={{
          listStyle: 'none',
          padding: 0,
          margin: 0,
          display: 'flex',
          flexDirection: 'column',
          gap: 'var(--space-2)',
        }}
      >
        {service.details.map((detail) => (
          <li
            key={detail}
            style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: 'var(--space-3)',
            }}
          >
            <span
              style={{
                width: '6px',
                height: '6px',
                minWidth: '6px',
                borderRadius: '50%',
                backgroundColor: 'var(--color-accent)',
                marginTop: '8px',
              }}
            />
            <span
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-sm)',
                color: 'var(--color-fg-secondary)',
                lineHeight: 'var(--line-height-normal)',
              }}
            >
              {detail}
            </span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
