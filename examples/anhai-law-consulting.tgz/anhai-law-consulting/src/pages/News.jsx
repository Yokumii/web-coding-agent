import { useState } from 'react';
import Container from '../components/Container';
import Section from '../components/Section';
import Card from '../components/Card';
import FadeIn from '../components/FadeIn';

const newsArticles = [
  {
    id: 1,
    title: 'Anhai Professional Expands Corporate Law Practice to Singapore',
    date: '2025-04-15',
    category: 'Company News',
    summary:
      'We are pleased to announce the expansion of our corporate law practice with a new office in Singapore, strengthening our presence in Southeast Asia and enhancing our ability to serve clients across the region.',
    content:
      "Anhai Professional is proud to announce the opening of our newest office in Singapore, marking a significant milestone in our firm's growth strategy. The new office will be led by Senior Partner David Chen, who brings over 20 years of experience in cross-border M&A and corporate governance.\n\nThis expansion reflects our commitment to meeting the growing demand for sophisticated legal counsel in Southeast Asia's dynamic business environment. The Singapore office will work closely with our Beijing headquarters and London office to provide seamless, round-the-clock service to our multinational clients.\n\n\"Singapore represents a crucial hub for international business, and our presence here will allow us to better serve clients navigating the complex regulatory landscape of the ASEAN region,\" said Managing Partner Li Wei.",
  },
  {
    id: 2,
    title: 'Landmark Victory in International Trade Dispute Arbitration',
    date: '2025-03-28',
    category: 'Case Update',
    summary:
      'Our dispute resolution team secured a landmark arbitration victory for a multinational manufacturing client, resolving a complex cross-border trade dispute valued at over $50 million.',
    content:
      "Anhai Professional's Dispute Resolution team, led by Partner Sarah Mitchell, has secured a landmark victory in an international arbitration proceeding under ICC rules. The case involved complex issues of trade law, contract interpretation, and jurisdictional challenges across three jurisdictions.\n\nAfter 18 months of intensive preparation and a two-week hearing, the tribunal ruled in favor of our client, awarding full damages and costs. The case sets an important precedent for how force majeure clauses are interpreted in long-term supply agreements in the post-pandemic era.\n\n\"This victory demonstrates the depth of expertise and strategic thinking that our team brings to the most challenging disputes,\" said Sarah Mitchell. \"Our client can now move forward with confidence, knowing their interests have been vigorously defended.\"",
  },
  {
    id: 3,
    title: 'Understanding the New EU Corporate Sustainability Reporting Directive',
    date: '2025-03-10',
    category: 'Legal Insight',
    summary:
      'The new CSRD introduces significant changes to corporate sustainability reporting requirements. Our corporate law team breaks down what businesses need to know to ensure compliance.',
    content:
      'The Corporate Sustainability Reporting Directive (CSRD) represents a paradigm shift in how companies operating in the EU must report on their environmental and social impact. Effective for fiscal years beginning on or after January 1, 2024, the directive significantly expands the scope of reporting obligations.\n\nKey changes include:\n\n- Expanded scope: The CSRD applies to all large companies and all companies listed on regulated markets (except listed micro-enterprises).\n- Double materiality: Companies must report not only on how sustainability issues affect their business (financial materiality) but also on their impact on people and the environment (impact materiality).\n- Assurance requirements: Sustainability reporting will require limited assurance, with a move toward reasonable assurance over time.\n\nOur corporate law team is advising clients on implementation strategies, gap analyses, and compliance roadmaps to meet these new requirements.',
  },
  {
    id: 4,
    title: 'Anhai Professional Recognized in Chambers Global 2025 Rankings',
    date: '2025-02-20',
    category: 'Awards',
    summary:
      'We are honored to be ranked in the Chambers Global 2025 guide for International Trade Law and Dispute Resolution, reflecting our continued commitment to excellence.',
    content:
      'Anhai Professional has been recognized in the prestigious Chambers Global 2025 guide, earning rankings in International Trade Law and Dispute Resolution. The firm was praised for its "exceptional client service" and "deep understanding of complex cross-border matters."\n\nIndividual accolades were also awarded to Partners Sarah Mitchell (Dispute Resolution) and David Chen (Corporate Law), both of whom were recognized as "Leading Individuals" in their respective practice areas.\n\n"These rankings reflect the hard work and dedication of our entire team," said Managing Partner Li Wei. "We are grateful to our clients for their trust and to Chambers for this recognition."',
  },
  {
    id: 5,
    title: 'Navigating Intellectual Property Protection in the Age of AI',
    date: '2025-01-15',
    category: 'Legal Insight',
    summary:
      'As artificial intelligence transforms industries, questions around IP ownership and protection have become increasingly complex. Our IP team explores the evolving landscape.',
    content:
      'The rapid advancement of artificial intelligence has created unprecedented challenges for intellectual property law. From AI-generated works to machine learning models trained on proprietary data, the boundaries of traditional IP frameworks are being tested.\n\nKey issues our IP team is tracking include:\n\n- Patent eligibility for AI inventions: Courts and patent offices worldwide are grappling with whether AI-generated inventions can be patented and who owns the rights.\n- Copyright in AI-generated content: The US Copyright Office has issued guidance suggesting that works created solely by AI may not qualify for copyright protection, but works with significant human input might.\n- Trade secret protection: As AI models become valuable business assets, protecting the underlying algorithms and training data as trade secrets has become critical.\n\nOur IP practice group is actively advising clients on developing strategies to protect their innovations in this rapidly evolving landscape.',
  },
  {
    id: 6,
    title: 'New Immigration Policy Changes Affecting Business Visas',
    date: '2024-12-05',
    category: 'Regulatory Update',
    summary:
      'Recent policy changes have streamlined the business visa application process while introducing new compliance requirements. Our immigration team provides an overview.',
    content:
      'Significant changes to business visa policies have taken effect this quarter, impacting multinational companies and their employees. Our immigration team has analyzed the new regulations and identified key changes that employers should be aware of.\n\nKey updates include:\n\n- Streamlined processing: Certain categories of business visas now benefit from expedited processing, with decisions expected within 15 business days for qualifying applicants.\n- Enhanced compliance requirements: Employers must now maintain more detailed records of sponsored employees, including updated salary benchmarks and role descriptions.\n- New visa categories: A specialized visa pathway has been introduced for professionals in emerging technology sectors.\n\nOur immigration team is available to guide clients through these changes and ensure continued compliance with all applicable regulations.',
  },
];

const categoryColors = {
  'Company News': '#2E8B57',
  'Case Update': '#C19A6B',
  'Legal Insight': '#2F4F4F',
  Awards: '#D4AF37',
  'Regulatory Update': '#5F7F7F',
};

export default function News() {
  const [expandedId, setExpandedId] = useState(null);

  const sortedArticles = [...newsArticles].sort(
    (a, b) => new Date(b.date) - new Date(a.date)
  );

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <>
      {/* Page Header */}
      <Section bg="primary" padding="lg">
        <Container>
          <div
            style={{
              textAlign: 'center',
              paddingTop: 'var(--space-8)',
              paddingBottom: 'var(--space-6)',
            }}
          >
            <FadeIn>
              <h1
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(var(--size-3xl), 6vw, var(--size-5xl))',
                  fontWeight: 'var(--weight-bold)',
                  color: 'var(--color-fg-primary)',
                  lineHeight: 'var(--line-height-tight)',
                  marginBottom: 'var(--space-5)',
                }}
              >
                News & Updates
              </h1>
            </FadeIn>
            <FadeIn delay={100}>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'clamp(var(--size-lg), 2vw, var(--size-xl))',
                  color: 'var(--color-fg-secondary)',
                  maxWidth: '720px',
                  margin: '0 auto',
                  lineHeight: 'var(--line-height-relaxed)',
                }}
              >
                Stay informed with the latest company announcements, legal
                insights, and industry updates from Anhai Professional.
              </p>
            </FadeIn>
          </div>
        </Container>
      </Section>

      {/* News Articles */}
      <Section bg="secondary" padding="lg">
        <Container>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 'var(--space-5)',
            }}
          >
            {sortedArticles.map((article, index) => (
              <FadeIn key={article.id} delay={index * 80}>
                <NewsCard
                  article={article}
                  expanded={expandedId === article.id}
                  onToggle={() =>
                    setExpandedId(
                      expandedId === article.id ? null : article.id
                    )
                  }
                  formatDate={formatDate}
                />
              </FadeIn>
            ))}
          </div>
        </Container>
      </Section>
    </>
  );
}

function NewsCard({ article, expanded, onToggle, formatDate }) {
  return (
    <Card
      variant="default"
      style={{
        cursor: 'pointer',
        transition: 'all var(--duration-normal) ease-in-out',
      }}
      onClick={onToggle}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = 'var(--color-accent)';
        e.currentTarget.style.transform = 'translateY(-2px)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = 'var(--color-border-light)';
        e.currentTarget.style.transform = 'translateY(0)';
      }}
    >
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          gap: 'var(--space-3)',
          marginBottom: 'var(--space-3)',
        }}
      >
        <span
          style={{
            display: 'inline-block',
            padding: '4px 12px',
            borderRadius: 'var(--radius-full)',
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--size-xs)',
            fontWeight: 'var(--weight-semibold)',
            letterSpacing: 'var(--letter-spacing-wide)',
            textTransform: 'uppercase',
            color: '#fff',
            backgroundColor:
              categoryColors[article.category] || 'var(--color-accent)',
          }}
        >
          {article.category}
        </span>
        <span
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--size-sm)',
            color: 'var(--color-fg-secondary)',
          }}
        >
          {formatDate(article.date)}
        </span>
      </div>

      <h2
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'clamp(var(--size-lg), 3vw, var(--size-xl))',
          fontWeight: 'var(--weight-semibold)',
          color: 'var(--color-fg-primary)',
          lineHeight: 'var(--line-height-tight)',
          marginBottom: 'var(--space-3)',
        }}
      >
        {article.title}
      </h2>

      <p
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-base)',
          color: 'var(--color-fg-secondary)',
          lineHeight: 'var(--line-height-relaxed)',
          marginBottom: expanded ? 'var(--space-5)' : '0',
        }}
      >
        {article.summary}
      </p>

      {expanded && (
        <div
          style={{
            marginTop: 'var(--space-5)',
            paddingTop: 'var(--space-5)',
            borderTop: '1px solid var(--color-border-light)',
          }}
        >
          <div
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: 'var(--size-base)',
              color: 'var(--color-fg-secondary)',
              lineHeight: 'var(--line-height-relaxed)',
              whiteSpace: 'pre-line',
            }}
          >
            {article.content}
          </div>
        </div>
      )}

      <div
        style={{
          marginTop: 'var(--space-4)',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          fontFamily: 'var(--font-body)',
          fontSize: 'var(--size-sm)',
          fontWeight: 'var(--weight-medium)',
          color: 'var(--color-accent)',
        }}
      >
        <span>{expanded ? 'Show Less' : 'Read More'}</span>
        <span
          style={{
            display: 'inline-block',
            transition: 'transform var(--duration-normal) ease-in-out',
            transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)',
          }}
        >
          <svg
            width="12"
            height="12"
            viewBox="0 0 12 12"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M2 4L6 8L10 4"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
      </div>
    </Card>
  );
}
