export default function Container({ children, className = '', style = {} }) {
  return (
    <div
      className={className}
      style={{
        width: '100%',
        maxWidth: 'var(--container-max)',
        marginLeft: 'auto',
        marginRight: 'auto',
        paddingLeft: 'var(--container-padding)',
        paddingRight: 'var(--container-padding)',
        ...style,
      }}
    >
      {children}
    </div>
  );
}
