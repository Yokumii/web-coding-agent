import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/services', label: 'Services' },
  { to: '/news', label: 'News' },
  { to: '/contact', label: 'Contact' },
];

export default function Nav() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  useEffect(() => {
    if (!mobileOpen) return;

    const handleClickOutside = (event) => {
      if (navRef.current && !navRef.current.contains(event.target)) {
        setMobileOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [mobileOpen]);

  return (
    <nav
      ref={navRef}
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 50,
        backgroundColor: scrolled
          ? 'rgba(255, 235, 205, 0.98)'
          : 'rgba(255, 235, 205, 0.95)',
        backdropFilter: 'blur(8px)',
        borderBottom: '1px solid var(--color-border-light)',
        transition: 'background-color var(--duration-normal) ease-in-out',
      }}
    >
      <div
        style={{
          maxWidth: 'var(--container-max)',
          margin: '0 auto',
          padding: '0 var(--container-padding)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: '64px',
        }}
      >
        <Link
          to="/"
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 'var(--size-xl)',
            fontWeight: 'var(--weight-semibold)',
            color: 'var(--color-fg-primary)',
            textDecoration: 'none',
            flexShrink: 0,
          }}
        >
          Anhai Professional
        </Link>

        {/* Desktop Nav */}
        <div
          style={{
            display: 'flex',
            gap: 'var(--space-6)',
            alignItems: 'center',
          }}
          className="nav-desktop"
        >
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              active={location.pathname === link.to}
            >
              {link.label}
            </NavLink>
          ))}
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: 'var(--space-2)',
            minWidth: '44px',
            minHeight: '44px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
          className="nav-mobile-toggle"
          aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'}
          aria-expanded={mobileOpen}
        >
          <div
            style={{
              width: '24px',
              height: '2px',
              backgroundColor: 'var(--color-fg-primary)',
              marginBottom: '6px',
              transition: 'all var(--duration-normal) ease-in-out',
              transform: mobileOpen ? 'rotate(45deg) translate(5px, 5px)' : 'none',
            }}
          />
          <div
            style={{
              width: '24px',
              height: '2px',
              backgroundColor: 'var(--color-fg-primary)',
              marginBottom: '6px',
              transition: 'all var(--duration-normal) ease-in-out',
              opacity: mobileOpen ? 0 : 1,
            }}
          />
          <div
            style={{
              width: '24px',
              height: '2px',
              backgroundColor: 'var(--color-fg-primary)',
              transition: 'all var(--duration-normal) ease-in-out',
              transform: mobileOpen ? 'rotate(-45deg) translate(5px, -5px)' : 'none',
            }}
          />
        </button>
      </div>

      {/* Mobile menu */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 'var(--space-4)',
          padding: 'var(--space-5) var(--container-padding)',
          borderTop: '1px solid var(--color-border-light)',
          backgroundColor: 'var(--color-bg-primary)',
          position: 'absolute',
          top: '64px',
          left: 0,
          right: 0,
          transform: mobileOpen ? 'translateY(0)' : 'translateY(-100%)',
          opacity: mobileOpen ? 1 : 0,
          pointerEvents: mobileOpen ? 'auto' : 'none',
          transition: 'transform var(--duration-normal) ease-in-out, opacity var(--duration-normal) ease-in-out',
          boxShadow: '0 4px 12px rgba(47, 79, 79, 0.1)',
        }}
        className="nav-mobile-menu"
      >
        {navLinks.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            active={location.pathname === link.to}
            onClick={() => setMobileOpen(false)}
            mobile
          >
            {link.label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}

function NavLink({ to, children, active, onClick, mobile }) {
  return (
    <Link
      to={to}
      onClick={onClick}
      style={{
        fontFamily: 'var(--font-body)',
        fontSize: mobile ? 'var(--size-lg)' : 'var(--size-sm)',
        fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: active ? 'var(--color-accent)' : 'var(--color-fg-primary)',
        textDecoration: 'none',
        letterSpacing: 'var(--letter-spacing-wide)',
        textTransform: 'uppercase',
        transition: 'color var(--duration-fast) ease-out',
        position: 'relative',
        paddingBottom: mobile ? 'var(--space-2)' : '2px',
        paddingTop: mobile ? 'var(--space-2)' : '0',
        minHeight: mobile ? '44px' : 'auto',
        display: 'flex',
        alignItems: 'center',
      }}
      onMouseEnter={(e) => {
        if (!active) e.currentTarget.style.color = 'var(--color-accent)';
      }}
      onMouseLeave={(e) => {
        if (!active) e.currentTarget.style.color = 'var(--color-fg-primary)';
      }}
    >
      {children}
      {active && !mobile && (
        <span
          style={{
            position: 'absolute',
            bottom: '-4px',
            left: 0,
            width: '100%',
            height: '2px',
            backgroundColor: 'var(--color-accent)',
          }}
        />
      )}
    </Link>
  );
}
