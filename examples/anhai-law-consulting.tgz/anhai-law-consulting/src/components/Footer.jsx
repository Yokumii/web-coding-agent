import { Link } from 'react-router-dom';
import Container from './Container';

const siteMapLinks = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/services', label: 'Services' },
  { to: '/news', label: 'News' },
  { to: '/contact', label: 'Contact' },
];

const serviceLinks = [
  'International Trade Law',
  'Corporate Law',
  'Intellectual Property',
  'Dispute Resolution',
  'Immigration Services',
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      style={{
        backgroundColor: 'var(--color-bg-dark)',
        color: 'var(--color-fg-on-dark)',
        paddingTop: 'var(--space-8)',
        paddingBottom: 'var(--space-6)',
      }}
    >
      <Container>
        {/* Main Footer Content */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: 'var(--space-7)',
            paddingBottom: 'var(--space-7)',
            borderBottom: '1px solid rgba(255, 235, 205, 0.15)',
          }}
        >
          {/* Brand & Description */}
          <div style={{ maxWidth: '320px' }}>
            <h3
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'var(--size-xl)',
                fontWeight: 'var(--weight-semibold)',
                color: 'var(--color-fg-on-dark)',
                marginBottom: 'var(--space-4)',
                lineHeight: 'var(--line-height-tight)',
              }}
            >
              Anhai Professional
            </h3>
            <p
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-sm)',
                color: 'var(--color-fg-on-dark)',
                lineHeight: 'var(--line-height-relaxed)',
                opacity: 0.8,
                marginBottom: 'var(--space-4)',
              }}
            >
              Expertise in International Trade Law, Corporate Advisory,
              and Cross-Border Dispute Resolution.
            </p>
            <div
              style={{
                width: '40px',
                height: '2px',
                backgroundColor: 'var(--color-accent)',
              }}
            />
          </div>

          {/* Site Map */}
          <div>
            <h4
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                fontWeight: 'var(--weight-semibold)',
                letterSpacing: 'var(--letter-spacing-wide)',
                textTransform: 'uppercase',
                color: 'var(--color-accent)',
                marginBottom: 'var(--space-4)',
              }}
            >
              Site Map
            </h4>
            <ul
              style={{
                listStyle: 'none',
                padding: 0,
                margin: 0,
                display: 'flex',
                flexDirection: 'column',
                gap: 'var(--space-3)',
              }}
            >
              {siteMapLinks.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    style={{
                      fontFamily: 'var(--font-body)',
                      fontSize: 'var(--size-sm)',
                      color: 'var(--color-fg-on-dark)',
                      textDecoration: 'none',
                      opacity: 0.8,
                      transition: 'opacity var(--duration-fast) ease-out',
                      display: 'inline-block',
                      minHeight: '24px',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.opacity = '1';
                      e.currentTarget.style.color = 'var(--color-accent-light)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.opacity = '0.8';
                      e.currentTarget.style.color = 'var(--color-fg-on-dark)';
                    }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                fontWeight: 'var(--weight-semibold)',
                letterSpacing: 'var(--letter-spacing-wide)',
                textTransform: 'uppercase',
                color: 'var(--color-accent)',
                marginBottom: 'var(--space-4)',
              }}
            >
              Practice Areas
            </h4>
            <ul
              style={{
                listStyle: 'none',
                padding: 0,
                margin: 0,
                display: 'flex',
                flexDirection: 'column',
                gap: 'var(--space-3)',
              }}
            >
              {serviceLinks.map((service) => (
                <li key={service}>
                  <Link
                    to="/services"
                    style={{
                      fontFamily: 'var(--font-body)',
                      fontSize: 'var(--size-sm)',
                      color: 'var(--color-fg-on-dark)',
                      textDecoration: 'none',
                      opacity: 0.8,
                      transition: 'opacity var(--duration-fast) ease-out',
                      display: 'inline-block',
                      minHeight: '24px',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.opacity = '1';
                      e.currentTarget.style.color = 'var(--color-accent-light)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.opacity = '0.8';
                      e.currentTarget.style.color = 'var(--color-fg-on-dark)';
                    }}
                  >
                    {service}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                fontWeight: 'var(--weight-semibold)',
                letterSpacing: 'var(--letter-spacing-wide)',
                textTransform: 'uppercase',
                color: 'var(--color-accent)',
                marginBottom: 'var(--space-4)',
              }}
            >
              Contact
            </h4>
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: 'var(--space-3)',
              }}
            >
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'var(--size-sm)',
                  color: 'var(--color-fg-on-dark)',
                  lineHeight: 'var(--line-height-relaxed)',
                  opacity: 0.8,
                }}
              >
                128 Chang&apos;an Avenue, Dongcheng District
                <br />
                Beijing, 100006, China
              </p>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'var(--size-sm)',
                  color: 'var(--color-fg-on-dark)',
                  opacity: 0.8,
                }}
              >
                <a
                  href="tel:+861088881234"
                  style={{
                    color: 'inherit',
                    textDecoration: 'none',
                    transition: 'color var(--duration-fast) ease-out',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = 'var(--color-accent-light)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = 'inherit';
                  }}
                >
                  +86 (10) 8888-1234
                </a>
              </p>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'var(--size-sm)',
                  color: 'var(--color-fg-on-dark)',
                  opacity: 0.8,
                }}
              >
                <a
                  href="mailto:contact@anhai-professional.com"
                  style={{
                    color: 'inherit',
                    textDecoration: 'none',
                    transition: 'color var(--duration-fast) ease-out',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = 'var(--color-accent-light)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = 'inherit';
                  }}
                >
                  contact@anhai-professional.com
                </a>
              </p>
              <p
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: 'var(--size-xs)',
                  color: 'var(--color-fg-on-dark)',
                  opacity: 0.6,
                  marginTop: 'var(--space-2)',
                }}
              >
                Mon – Fri: 9:00 AM – 6:00 PM CST
                <br />
                Sat: 10:00 AM – 2:00 PM CST
              </p>
            </div>
          </div>
        </div>

        {/* Legal Bar */}
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: 'var(--space-4)',
            paddingTop: 'var(--space-6)',
          }}
        >
          <p
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: 'var(--size-xs)',
              color: 'var(--color-fg-on-dark)',
              opacity: 0.6,
            }}
          >
            &copy; {currentYear} Anhai Professional Law Firm. All rights reserved.
          </p>
          <div
            style={{
              display: 'flex',
              gap: 'var(--space-5)',
              flexWrap: 'wrap',
              alignItems: 'center',
            }}
          >
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                color: 'var(--color-fg-on-dark)',
                opacity: 0.6,
                textDecoration: 'none',
                transition: 'opacity var(--duration-fast) ease-out, color var(--duration-fast) ease-out',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.opacity = '1';
                e.currentTarget.style.color = 'var(--color-accent-light)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.opacity = '0.6';
                e.currentTarget.style.color = 'var(--color-fg-on-dark)';
              }}
            >
              Back to Top
            </a>
            <Link
              to="#"
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                color: 'var(--color-fg-on-dark)',
                opacity: 0.6,
                textDecoration: 'none',
                transition: 'opacity var(--duration-fast) ease-out, color var(--duration-fast) ease-out',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.opacity = '1';
                e.currentTarget.style.color = 'var(--color-accent-light)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.opacity = '0.6';
                e.currentTarget.style.color = 'var(--color-fg-on-dark)';
              }}
            >
              Privacy Policy
            </Link>
            <Link
              to="#"
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                color: 'var(--color-fg-on-dark)',
                opacity: 0.6,
                textDecoration: 'none',
                transition: 'opacity var(--duration-fast) ease-out, color var(--duration-fast) ease-out',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.opacity = '1';
                e.currentTarget.style.color = 'var(--color-accent-light)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.opacity = '0.6';
                e.currentTarget.style.color = 'var(--color-fg-on-dark)';
              }}
            >
              Terms of Service
            </Link>
            <Link
              to="#"
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: 'var(--size-xs)',
                color: 'var(--color-fg-on-dark)',
                opacity: 0.6,
                textDecoration: 'none',
                transition: 'opacity var(--duration-fast) ease-out, color var(--duration-fast) ease-out',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.opacity = '1';
                e.currentTarget.style.color = 'var(--color-accent-light)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.opacity = '0.6';
                e.currentTarget.style.color = 'var(--color-fg-on-dark)';
              }}
            >
              Disclaimer
            </Link>
          </div>
        </div>
      </Container>
    </footer>
  );
}
