export default function Card({
  children,
  className = '',
  style = {},
  variant = 'default',
  onClick,
  onMouseEnter,
  onMouseLeave,
}) {
  const variants = {
    default: {
      backgroundColor: 'var(--color-bg-secondary)',
      border: '1px solid var(--color-border-light)',
    },
    dark: {
      backgroundColor: 'var(--color-bg-dark)',
      border: '1px solid var(--color-border)',
      color: 'var(--color-fg-on-dark)',
    },
    outline: {
      backgroundColor: 'transparent',
      border: '1px solid var(--color-border)',
    },
  };

  return (
    <div
      className={className}
      style={{
        borderRadius: 'var(--radius-lg)',
        padding: 'var(--space-6)',
        transition: 'all var(--duration-normal) ease-in-out',
        ...variants[variant],
        ...style,
      }}
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      {children}
    </div>
  );
}
