export default function Section({
  children,
  className = '',
  style = {},
  bg = 'primary',
  padding = 'md',
  id,
}) {
  const bgColors = {
    primary: 'var(--color-bg-primary)',
    secondary: 'var(--color-bg-secondary)',
    dark: 'var(--color-bg-dark)',
  };

  const paddings = {
    sm: 'var(--section-padding-sm)',
    md: 'var(--section-padding-md)',
    lg: 'var(--section-padding-lg)',
  };

  return (
    <section
      id={id}
      className={className}
      style={{
        backgroundColor: bgColors[bg] || bg,
        paddingTop: paddings[padding] || padding,
        paddingBottom: paddings[padding] || padding,
        ...style,
      }}
    >
      {children}
    </section>
  );
}
