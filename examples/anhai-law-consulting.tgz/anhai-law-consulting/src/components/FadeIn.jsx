import useInView from '../hooks/useInView';

const prefersReducedMotion =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export default function FadeIn({
  children,
  delay = 0,
  direction = 'up',
  duration = 600,
  className = '',
  style = {},
  as: Component = 'div',
  once = true,
  threshold,
  rootMargin,
}) {
  const { ref, isInView } = useInView({ once, threshold, rootMargin });

  const getInitialTransform = () => {
    switch (direction) {
      case 'up':
        return 'translateY(30px)';
      case 'down':
        return 'translateY(-30px)';
      case 'left':
        return 'translateX(30px)';
      case 'right':
        return 'translateX(-30px)';
      default:
        return 'translateY(30px)';
    }
  };

  const combinedStyle = prefersReducedMotion
    ? { ...style }
    : {
        opacity: isInView ? 1 : 0,
        transform: isInView ? 'translate(0, 0)' : getInitialTransform(),
        transition: `opacity ${duration}ms cubic-bezier(0, 0, 0.2, 1) ${delay}ms, transform ${duration}ms cubic-bezier(0, 0, 0.2, 1) ${delay}ms`,
        willChange: 'opacity, transform',
        ...style,
      };

  return (
    <Component ref={ref} className={className} style={combinedStyle}>
      {children}
    </Component>
  );
}
