import { Link } from 'react-router-dom';

const variantStyles = {
  primary: {
    backgroundColor: 'var(--color-accent)',
    color: 'var(--color-fg-on-dark)',
    border: '1px solid var(--color-accent)',
  },
  secondary: {
    backgroundColor: 'transparent',
    color: 'var(--color-fg-primary)',
    border: '1px solid var(--color-border)',
  },
  outline: {
    backgroundColor: 'transparent',
    color: 'var(--color-fg-on-dark)',
    border: '1px solid var(--color-fg-on-dark)',
  },
};

const sizeStyles = {
  sm: { padding: '8px 16px', fontSize: 'var(--size-sm)' },
  md: { padding: '12px 24px', fontSize: 'var(--size-base)' },
  lg: { padding: '16px 32px', fontSize: 'var(--size-lg)' },
};

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  to,
  href,
  onClick,
  type = 'button',
  className = '',
  disabled = false,
  ...props
}) {
  const baseStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    borderRadius: 'var(--radius-md)',
    fontWeight: 'var(--weight-medium)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all var(--duration-normal) ease-in-out',
    textDecoration: 'none',
    opacity: disabled ? 0.6 : 1,
    ...variantStyles[variant],
    ...sizeStyles[size],
  };

  const hoverStyle = {
    onMouseEnter: (e) => {
      if (variant === 'primary') {
        e.currentTarget.style.backgroundColor = 'var(--color-accent-hover)';
      } else if (variant === 'secondary') {
        e.currentTarget.style.backgroundColor = 'var(--color-bg-secondary)';
      } else if (variant === 'outline') {
        e.currentTarget.style.backgroundColor = 'rgba(255, 235, 205, 0.1)';
      }
    },
    onMouseLeave: (e) => {
      if (variant === 'primary') {
        e.currentTarget.style.backgroundColor = 'var(--color-accent)';
      } else if (variant === 'secondary') {
        e.currentTarget.style.backgroundColor = 'transparent';
      } else if (variant === 'outline') {
        e.currentTarget.style.backgroundColor = 'transparent';
      }
    },
  };

  const combinedProps = {
    style: baseStyle,
    className,
    ...props,
  };

  if (to) {
    return (
      <Link to={to} {...combinedProps} {...hoverStyle}>
        {children}
      </Link>
    );
  }

  if (href) {
    return (
      <a href={href} {...combinedProps} {...hoverStyle}>
        {children}
      </a>
    );
  }

  return (
    <button type={type} {...combinedProps} {...hoverStyle} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}
